
import React from 'react';

const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18M3.75 9h16.5M3.75 15h16.5M12 3c-2.488 0-4.5 2.012-4.5 4.5S9.512 12 12 12s4.5-2.012 4.5-4.5S14.488 3 12 3zm0 18c-2.488 0-4.5-2.012-4.5-4.5S9.512 12 12 12s4.5 2.012 4.5 4.5S14.488 21 12 21zm-5.25-9H3.75m16.5 0H17.25" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export default GiftIcon;
