
import React from 'react';

const DashboardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l3-3m0 0l3 3m-3-3v12m5.25-9l3-3m0 0l3 3m-3-3v12M21 13.5l-3-3m0 0l-3 3m3-3v12" />
  </svg>
);

export default DashboardIcon;
