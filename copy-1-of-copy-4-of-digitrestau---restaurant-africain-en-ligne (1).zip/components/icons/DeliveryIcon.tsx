
import React from 'react';

const DeliveryIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2.14-1.284A2 2 0 016.14 15H13zm-3-5h4M13 8h4m-5 8H5.86a2 2 0 01-1.79-.894L3 13m15 4a2 2 0 10-4 0 2 2 0 004 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 17h-1a2 2 0 10-4 0h1m4 0h1m-1 0v-4.14a2 2 0 00-.86-1.638l-2.28-1.52a2 2 0 00-2.02 0L9 11.222M19 17h2a1 1 0 001-1v-3.333a1 1 0 00-.57-.905l-3-1.667a1 1 0 00-.86.055L14 11.222" />
    </svg>
);

export default DeliveryIcon;
