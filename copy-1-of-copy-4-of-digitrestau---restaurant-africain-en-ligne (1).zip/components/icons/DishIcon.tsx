
import React from 'react';

const DishIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 10.5a2.625 2.625 0 00-5.25 0-8.25 8.25 0 01-16.5 0" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 10.5v-.875c0-2.837 2.313-5.125 5.125-5.125h1.5c2.812 0 5.125 2.288 5.125 5.125v.875m-11.25 0h11.25" />
    </svg>
);

export default DishIcon;
