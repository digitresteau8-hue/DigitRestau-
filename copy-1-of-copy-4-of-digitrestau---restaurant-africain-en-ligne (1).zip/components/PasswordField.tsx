
import React, { useState } from 'react';
import EyeIcon from './icons/EyeIcon';
import EyeOffIcon from './icons/EyeOffIcon';

interface PasswordFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
    id: string;
    label: string;
}

const PasswordField: React.FC<PasswordFieldProps> = ({ id, label, ...props }) => {
    const [showPassword, setShowPassword] = useState(false);

    return (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-stone-700">{label}</label>
            <div className="mt-1 relative">
                <input
                    id={id}
                    type={showPassword ? 'text' : 'password'}
                    className="block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-amber-600 focus:border-amber-600"
                    required
                    {...props}
                />
                <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 px-3 flex items-center text-stone-500 hover:text-stone-700"
                    aria-label={showPassword ? 'Cacher le mot de passe' : 'Afficher le mot de passe'}
                >
                    {showPassword ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                </button>
            </div>
        </div>
    );
};

export default PasswordField;
