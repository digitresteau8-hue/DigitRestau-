
import React, { useState } from 'react';
import PhoneIcon from './icons/PhoneIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';
import ClockIcon from './icons/ClockIcon';
import MapPinIcon from './icons/MapPinIcon';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';

const ContactInfoItem: React.FC<{ icon: React.ReactNode; children: React.ReactNode }> = ({ icon, children }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 mt-1 text-amber-500">{icon}</div>
        <div>{children}</div>
    </div>
);

const SocialLink: React.FC<{ href: string; icon: React.ReactNode; label: string }> = ({ href, icon, label }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-3 text-stone-400 hover:text-amber-500 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">
        {icon}
        <span className="font-medium">{label}</span>
    </a>
);

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b border-white/10 last:border-0">
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center py-4 text-left focus:outline-none group"
            >
                <span className={`font-medium transition-colors ${isOpen ? 'text-cyan-400' : 'text-slate-200 group-hover:text-cyan-400'}`}>
                    {question}
                </span>
                <ChevronRightIcon className={`w-5 h-5 text-slate-500 transition-transform duration-300 ${isOpen ? 'rotate-90 text-cyan-400' : ''}`} />
            </button>
            <div 
                className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-40 opacity-100 mb-4' : 'max-h-0 opacity-0'}`}
            >
                <p className="text-slate-400 text-sm leading-relaxed pl-2 border-l-2 border-amber-500/50 ml-1">
                    {answer}
                </p>
            </div>
        </div>
    );
};


const ClientContactPage: React.FC = () => {
  return (
    <section id="contact" className="pt-28 pb-10 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
           <div className="inline-block bg-stone-900/80 p-4 rounded-full mb-4 border border-amber-500/30">
                <PhoneIcon className="w-10 h-10 text-amber-500" />
            </div>
          <h2 className="text-4xl font-bold font-serif text-white mb-4">Contactez-Nous & Commandez</h2>
          <p className="text-lg text-stone-400 max-w-2xl mx-auto">
            Une question ? Une envie ? Nous sommes à votre écoute pour prendre votre commande.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Info Block */}
            <div className="bg-stone-900/80 backdrop-blur-md p-8 md:p-12 rounded-xl shadow-lg border border-white/5 h-fit">
                <div className="grid md:grid-cols-2 gap-12">
                    <div className="space-y-8">
                        <ContactInfoItem icon={<PhoneIcon className="w-6 h-6" />}>
                            <p className="text-lg font-semibold text-white">Par Téléphone</p>
                            <a href="tel:+22770032552" className="block text-stone-400 hover:text-amber-500 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">+227 70 03 25 52</a>
                            <a href="tel:+22774441621" className="block text-stone-400 hover:text-amber-500 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">+227 74 44 16 21</a>
                        </ContactInfoItem>

                        <ContactInfoItem icon={<WhatsAppIcon className="w-6 h-6" />}>
                            <p className="text-lg font-semibold text-white">Via WhatsApp</p>
                            <a href="https://wa.me/22770032552" target="_blank" rel="noopener noreferrer" className="block text-stone-400 hover:text-amber-500 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">+227 70 03 25 52</a>
                            <a href="https://wa.me/22774441621" target="_blank" rel="noopener noreferrer" className="block text-stone-400 hover:text-amber-500 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">+227 74 44 16 21</a>
                        </ContactInfoItem>
                        
                        <ContactInfoItem icon={<ClockIcon className="w-6 h-6" />}>
                            <p className="text-lg font-semibold text-white">Horaires d'Ouverture</p>
                            <p className="text-stone-400">7/7 jours, de 09h à 22h</p>
                        </ContactInfoItem>

                        <ContactInfoItem icon={<MapPinIcon className="w-6 h-6" />}>
                            <p className="text-lg font-semibold text-white">Emplacement</p>
                            <p className="text-stone-400">Niamey, Niger (Service 100% en ligne)</p>
                        </ContactInfoItem>
                    </div>
                    <div className="space-y-8">
                        <div>
                            <h3 className="text-2xl font-bold font-serif text-white mb-6">Suivez nos aventures</h3>
                            <div className="space-y-4">
                                <SocialLink href="#" icon={<FacebookIcon className="w-7 h-7" />} label="@Allorestau" />
                                <SocialLink href="#" icon={<InstagramIcon className="w-7 h-7" />} label="@digitrestau" />
                            </div>
                        </div>
                        <div>
                            <h3 className="text-2xl font-bold font-serif text-white mb-6">Partenaire de Livraison</h3>
                            <div className="flex items-center space-x-4 bg-slate-800/50 p-4 rounded-lg border border-white/5">
                            <img src="https://picsum.photos/seed/delivery/60/60" alt="Billo Express logo" className="rounded-full border border-white/10" />
                            <div>
                                <p className="text-lg font-semibold text-white">Billo Express</p>
                                <p className="text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">Rapide - Fiable - Sécurisé</p>
                                <a href="tel:+22792080822" className="text-stone-400 hover:text-white transition-transform duration-300 ease-in-out transform hover:-translate-y-1 block font-mono text-sm">+227 92 08 08 22</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* FAQ Section */}
            <div className="bg-slate-900/80 backdrop-blur-md p-8 rounded-xl shadow-lg border border-white/5 h-fit">
                <h3 className="text-2xl font-bold font-serif text-white mb-6 flex items-center gap-2">
                    <span className="text-cyan-400">?</span> Questions Fréquentes
                </h3>
                <div className="space-y-2">
                    <FAQItem 
                        question="Quels sont les délais de livraison ?" 
                        answer="Nous livrons généralement en 45 à 60 minutes après confirmation de votre commande, selon votre localisation à Niamey et l'affluence." 
                    />
                    <FAQItem 
                        question="Quels moyens de paiement acceptez-vous ?" 
                        answer="Vous pouvez payer en espèces à la livraison ou via Mobile Money (Mynita, Amanata, Alliza, Zeyna)." 
                    />
                    <FAQItem 
                        question="Livrez-vous partout à Niamey ?" 
                        answer="Nous couvrons la majorité des quartiers de Niamey. Les tarifs varient selon la zone (Centre-ville ou Périphérie)." 
                    />
                    <FAQItem 
                        question="Proposez-vous un service traiteur ?" 
                        answer="Oui ! Pour vos événements (mariages, anniversaires, réunions), contactez-nous au moins 48h à l'avance pour un devis personnalisé." 
                    />
                    <FAQItem 
                        question="Comment fonctionnent les points de fidélité ?" 
                        answer="Chaque commande vous rapporte des points (1000F = 10 points). Échangez-les ensuite contre des boissons gratuites ou des réductions depuis votre espace compte." 
                    />
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default ClientContactPage;
