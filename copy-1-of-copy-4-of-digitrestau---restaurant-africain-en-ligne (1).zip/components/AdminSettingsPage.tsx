




import React, { useState, useEffect } from 'react';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';
import { Settings } from './data';

interface AdminSettingsPageProps {
    settings: Settings;
    onUpdateSettings: (settings: Settings) => void;
    showNotification: (message: string, type: 'success' | 'error' | 'info') => void;
}

const StringListManager: React.FC<{
    title: string;
    items: string[];
    onItemsChange: (newItems: string[]) => void;
    placeholder: string;
}> = ({ title, items, onItemsChange, placeholder }) => {
    const [newItem, setNewItem] = useState('');

    const handleAddItem = () => {
        if (newItem && !items.find(i => i.toLowerCase() === newItem.toLowerCase())) {
            onItemsChange([...items, newItem]);
            setNewItem('');
        }
    };

    const handleRemoveItem = (itemToRemove: string) => {
        onItemsChange(items.filter(item => item !== itemToRemove));
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-lg h-full flex flex-col">
            <h2 className="text-xl font-bold text-stone-800 mb-4">{title}</h2>
            <div className="space-y-2 mb-4 flex-grow">
                {items.length > 0 ? items.map(item => (
                    <div key={item} className="flex justify-between items-center bg-stone-50 p-2 rounded-md">
                        <span className="font-medium capitalize">{item}</span>
                        <button onClick={() => handleRemoveItem(item)} className="p-1 text-stone-400 hover:text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4"/></button>
                    </div>
                )) : <p className="text-sm text-stone-500 italic">Aucun élément.</p>}
            </div>
            <div className="flex space-x-2">
                <input 
                    type="text" 
                    value={newItem} 
                    onChange={(e) => setNewItem(e.target.value)} 
                    placeholder={placeholder}
                    className="flex-grow border-gray-300 rounded-md shadow-sm"
                />
                <button onClick={handleAddItem} className="p-2 bg-amber-700 text-white rounded-md hover:bg-amber-800"><PlusIcon className="w-5 h-5"/></button>
            </div>
        </div>
    );
};


const AdminSettingsPage: React.FC<AdminSettingsPageProps> = ({ settings, onUpdateSettings, showNotification }) => {
  const [localSettings, setLocalSettings] = useState<Settings>(settings);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleFieldChange = (field: keyof Settings, value: any) => {
    setLocalSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleFeeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      handleFieldChange('deliveryFees', { ...localSettings.deliveryFees, [name]: Number(value) });
  };

  const handleHoursChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    handleFieldChange('openingHours', { ...localSettings.openingHours, [name]: value });
  };
  
  const handleSave = () => {
      setIsSaving(true);
      onUpdateSettings(localSettings);
      setTimeout(() => setIsSaving(false), 1000); 
  };

  return (
    <div>
      <h1 className="text-3xl font-bold font-serif text-stone-900 mb-6">Paramètres Généraux</h1>
      <div className="space-y-8">
        
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-bold text-stone-800 mb-4">Horaires d'Ouverture</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
                <label htmlFor="weekdays" className="block text-sm font-medium text-stone-700">Lundi - Samedi</label>
                <input type="text" name="weekdays" id="weekdays" value={localSettings.openingHours.weekdays} onChange={handleHoursChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
             </div>
             <div>
                <label htmlFor="sunday" className="block text-sm font-medium text-stone-700">Dimanche</label>
                <input type="text" name="sunday" id="sunday" value={localSettings.openingHours.sunday} onChange={handleHoursChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
             </div>
          </div>
        </div>

        <StringListManager
            title="Modes de Paiement"
            items={localSettings.paymentMethods}
            onItemsChange={(newItems) => handleFieldChange('paymentMethods', newItems)}
            placeholder="Nouveau mode de paiement"
        />

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-bold text-stone-800 mb-4">Frais de Livraison</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <h3 className="font-semibold text-stone-700 mb-3">Tarifs Journée</h3>
                <div className="space-y-3">
                    <div>
                    <label htmlFor="centreVille" className="block text-sm font-medium text-stone-700">Centre ville (CFA)</label>
                    <input type="number" name="centreVille" id="centreVille" value={localSettings.deliveryFees.centreVille} onChange={handleFeeChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                    </div>
                    <div>
                    <label htmlFor="peripherie" className="block text-sm font-medium text-stone-700">Périphérie (CFA)</label>
                    <input type="number" name="peripherie" id="peripherie" value={localSettings.deliveryFees.peripherie} onChange={handleFeeChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                    </div>
                </div>
            </div>
            <div>
                 <h3 className="font-semibold text-stone-700 mb-3">Tarifs Nuit (> 21h)</h3>
                 <div className="space-y-3">
                    <div>
                    <label htmlFor="nightCentreVille" className="block text-sm font-medium text-stone-700">Centre ville Nuit (CFA)</label>
                    <input type="number" name="nightCentreVille" id="nightCentreVille" value={localSettings.deliveryFees.nightCentreVille || 0} onChange={handleFeeChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                    </div>
                     <div>
                    <label htmlFor="nightPeripherie" className="block text-sm font-medium text-stone-700">Périphérie Nuit (CFA)</label>
                    <input type="number" name="nightPeripherie" id="nightPeripherie" value={localSettings.deliveryFees.nightPeripherie || 0} onChange={handleFeeChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                    </div>
                 </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <StringListManager
                title="Quartiers du Centre-Ville"
                items={localSettings.deliveryZones?.centreVille || []}
                onItemsChange={(newItems) => handleFieldChange('deliveryZones', { ...localSettings.deliveryZones, centreVille: newItems })}
                placeholder="Nom du quartier"
            />
            <StringListManager
                title="Quartiers Périphériques"
                items={localSettings.deliveryZones?.peripherie || []}
                onItemsChange={(newItems) => handleFieldChange('deliveryZones', { ...localSettings.deliveryZones, peripherie: newItems })}
                placeholder="Nom du quartier"
            />
        </div>


        <div className="flex justify-end items-center mt-8 space-x-4">
            <button 
                onClick={handleSave}
                disabled={isSaving}
                className="bg-amber-700 text-white font-bold py-3 px-6 rounded-lg hover:bg-amber-800 transition duration-300 shadow-lg disabled:bg-amber-500 disabled:cursor-not-allowed"
            >
                {isSaving ? 'Sauvegarde...' : 'Sauvegarder les Modifications'}
            </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSettingsPage;