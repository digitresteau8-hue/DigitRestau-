
import React, { useState, useRef } from 'react';
import PasswordField from './PasswordField';
import PhoneField from './PhoneField';
import UserIcon from './icons/UserIcon';
import { User, rewards, LoyaltyReward } from './data';
import LogoutIcon from './icons/LogoutIcon';
import { authSignUp, authUpdateUser } from './db';
import { supabase } from './supabaseClient';
import TicketIcon from './icons/TicketIcon';
import GiftIcon from './icons/GiftIcon';
import CameraIcon from './icons/CameraIcon';

interface ClientAccountPageProps {
  onLogin: (identifier: string, password: string) => void;
  onLogout: () => void;
  currentUser: User | null;
  onBecomeAdmin?: () => void;
}

// Fonction utilitaire pour redimensionner les images (Base64)
const resizeImage = (file: File, maxWidth: number, maxHeight: number): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', 0.7)); // Compression 70%
            };
            img.onerror = reject;
        };
        reader.onerror = reject;
    });
};

// Composant Carte de Fidélité Holographique
const LoyaltyCard: React.FC<{ user: User }> = ({ user }) => {
    return (
        <div className="relative w-full max-w-sm mx-auto h-56 rounded-2xl overflow-hidden transform transition-transform hover:scale-105 duration-500 perspective-1000 shadow-2xl shadow-cyan-500/20 border border-white/10 group">
            {/* Background Holographique */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-cyan-900"></div>
            <div className="absolute inset-0 opacity-30 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
            <div className="absolute -top-20 -right-20 w-60 h-60 bg-cyan-500 rounded-full blur-[80px] opacity-40 animate-pulse"></div>
            
            <div className="relative z-10 p-6 flex flex-col justify-between h-full">
                <div className="flex justify-between items-start">
                    <img src="https://i.ibb.co/WWHPStfL/1759863774896.png" alt="Logo" className="h-10 opacity-90" />
                    <div className="flex flex-col items-end">
                        <span className="px-3 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/50 rounded-full text-xs font-bold tracking-widest uppercase shadow-[0_0_10px_rgba(245,158,11,0.3)]">
                            Gold Member
                        </span>
                    </div>
                </div>
                
                <div className="flex items-center gap-4">
                    <div className="relative w-16 h-16 rounded-full p-0.5 bg-gradient-to-r from-cyan-400 to-blue-600 shadow-lg">
                        <div className="w-full h-full rounded-full overflow-hidden bg-slate-900 flex items-center justify-center">
                            {user.avatarUrl ? (
                                <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                            ) : (
                                <UserIcon className="w-8 h-8 text-slate-400" />
                            )}
                        </div>
                    </div>
                    <div>
                        <p className="text-cyan-300 text-xs uppercase tracking-widest mb-1">Solde Points</p>
                        <p className="text-4xl font-bold text-white drop-shadow-lg flex items-baseline gap-2">
                            {user.points || 0} <span className="text-lg font-normal text-slate-400">PTS</span>
                        </p>
                    </div>
                </div>

                <div className="flex justify-between items-end">
                    <div>
                        <p className="text-slate-400 text-xs uppercase">Titulaire</p>
                        <p className="text-white font-semibold tracking-wide text-lg shadow-black drop-shadow-md">{user.name}</p>
                    </div>
                     <div>
                        <p className="text-slate-400 text-xs uppercase text-right">ID Membre</p>
                        <p className="text-white font-mono text-sm shadow-black drop-shadow-md">#{user.id.slice(0, 8).toUpperCase()}</p>
                    </div>
                </div>
            </div>
            
            {/* Shine Effect */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
        </div>
    );
};

const ClientAccountPage: React.FC<ClientAccountPageProps> = ({ onLogin, onLogout, currentUser, onBecomeAdmin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [signupName, setSignupName] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showAdminInput, setShowAdminInput] = useState(false);
  const [adminCode, setAdminCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
        if (isLogin) {
            await onLogin(loginIdentifier, loginPassword);
        } else {
            if (!signupPhone || !/^\d{8}$/.test(signupPhone)) throw new Error("Numéro de téléphone invalide (8 chiffres requis).");
            if (signupPassword.length < 6) throw new Error("Le mot de passe doit contenir au moins 6 caractères.");
            if (signupPassword !== signupConfirmPassword) throw new Error("Les mots de passe ne correspondent pas.");
            
            if (supabase) {
                const emailToUse = signupEmail || `${signupPhone}@digitrestau.com`;
                await authSignUp(emailToUse, signupPassword, { name: signupName, phone: signupPhone });
                alert("Compte créé avec succès ! Veuillez vérifier vos emails si vous en avez fourni un, ou connectez-vous.");
                setIsLogin(true);
                setLoginIdentifier(emailToUse);
                setLoginPassword('');
            } else {
                alert(`[Mode Démo] Inscription simulée pour ${signupName}.`);
                setIsLogin(true);
                setLoginIdentifier(signupPhone);
            }
        }
    } catch (err: any) {
        console.error(err);
        setError(err.message || "Une erreur est survenue.");
    } finally {
        setIsLoading(false);
    }
  };
  
  const handleAdminSubmit = () => {
      if (adminCode === 'DIGIT2024') {
          if (onBecomeAdmin) onBecomeAdmin();
      } else {
          alert("Code incorrect.");
      }
  };
  
  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setIsUploading(true);
      try {
          // 1. Resize image (Max 200x200 for metadata storage)
          const base64Image = await resizeImage(file, 200, 200);
          
          // 2. Update user metadata via Supabase or Local Logic
          await authUpdateUser({ avatarUrl: base64Image });
          
          // 3. Force refresh (dirty hack: reload page or let realtime handle it)
          // In a real app, state should update automatically. Here we rely on App.tsx to re-fetch user or we just wait a bit.
          alert("Photo de profil mise à jour !");
          window.location.reload(); // Simple reload to show new avatar everywhere
          
      } catch (err) {
          console.error("Upload failed", err);
          alert("Erreur lors de la mise à jour de la photo.");
      } finally {
          setIsUploading(false);
      }
  };
  
  const redeemReward = (reward: LoyaltyReward) => {
      if (!currentUser || (currentUser.points || 0) < reward.cost) {
          alert("Points insuffisants !");
          return;
      }
      if (window.confirm(`Échanger ${reward.cost} points contre : ${reward.name} ?`)) {
          alert(`Félicitations ! Vous avez débloqué : ${reward.name}. Présentez ce message lors de votre commande ou contactez le support.`);
          // Note: La mise à jour réelle des points nécessiterait un appel backend ici
      }
  }
  
  if (currentUser) {
    return (
        <section id="account-profile" className="pt-28 pb-10 min-h-screen">
             <div className="container mx-auto px-6">
                 <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
                     
                    {/* Colonne Gauche : Profil & Carte */}
                    <div className="space-y-8">
                        <div className="text-center lg:text-left">
                            <h2 className="text-3xl font-bold font-serif text-white mb-2">Espace Membre</h2>
                            <p className="text-cyan-400">Bienvenue dans le futur de la restauration.</p>
                        </div>
                        
                        <LoyaltyCard user={currentUser} />
                        
                        <div className="bg-slate-900/80 backdrop-blur-md p-6 rounded-xl border border-white/5 shadow-lg relative">
                            {/* Upload Avatar Button */}
                            <input 
                                type="file" 
                                ref={fileInputRef} 
                                className="hidden" 
                                accept="image/*"
                                onChange={handleAvatarChange}
                            />
                            <button 
                                onClick={() => fileInputRef.current?.click()}
                                disabled={isUploading}
                                className="absolute top-6 right-6 bg-slate-800 hover:bg-cyan-600 text-white p-2 rounded-full shadow-lg border border-white/10 transition-all duration-300 group z-20"
                                title="Changer de photo"
                            >
                                <CameraIcon className={`w-5 h-5 ${isUploading ? 'animate-spin' : ''}`} />
                            </button>

                            <div className="flex items-center space-x-4 mb-6 border-b border-white/5 pb-4">
                                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-cyan-500/30 bg-slate-800 flex items-center justify-center">
                                     {currentUser.avatarUrl ? (
                                        <img src={currentUser.avatarUrl} alt="Profile" className="w-full h-full object-cover" />
                                     ) : (
                                        <UserIcon className="w-6 h-6 text-cyan-400"/>
                                     )}
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs uppercase">Informations</p>
                                    <p className="text-white font-semibold">{currentUser.name}</p>
                                    <p className="text-slate-400 text-sm">+227 {currentUser.phone}</p>
                                </div>
                            </div>
                             <button 
                                onClick={onLogout}
                                className="w-full flex justify-center items-center space-x-2 py-3 px-4 border border-red-500/30 rounded-lg text-sm font-bold text-red-400 hover:bg-red-900/20 transition-all"
                            >
                                <LogoutIcon className="w-5 h-5" />
                                <span>Se Déconnecter</span>
                            </button>
                             {/* Zone Admin Secrète */}
                            <div className="pt-4 mt-4 border-t border-white/5 text-center">
                                {!showAdminInput ? (
                                    <button onClick={() => setShowAdminInput(true)} className="text-xs text-slate-700 hover:text-cyan-500 transition-colors">Accès Staff</button>
                                ) : (
                                    <div className="flex items-center space-x-2 justify-center animate-fade-in">
                                        <input type="password" placeholder="Code Staff" value={adminCode} onChange={(e) => setAdminCode(e.target.value)} className="text-sm border border-slate-700 bg-slate-950 text-white rounded px-2 py-1 w-32 focus:border-cyan-500 outline-none" />
                                        <button onClick={handleAdminSubmit} className="bg-cyan-600 text-white text-xs px-3 py-1 rounded hover:bg-cyan-500">OK</button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Colonne Droite : Boutique Cadeaux */}
                    <div>
                        <h3 className="text-2xl font-bold font-serif text-white mb-6 flex items-center gap-3">
                            <GiftIcon className="w-8 h-8 text-amber-400" />
                            Boutique Récompenses
                        </h3>
                        <div className="grid sm:grid-cols-2 gap-4">
                            {rewards.map(reward => {
                                const canAfford = (currentUser.points || 0) >= reward.cost;
                                return (
                                    <div key={reward.id} className={`p-4 rounded-xl border transition-all duration-300 relative overflow-hidden group ${canAfford ? 'bg-slate-900 border-cyan-500/30 hover:border-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.2)]' : 'bg-slate-900/50 border-white/5 opacity-60'}`}>
                                        <div className="flex justify-between items-start mb-2">
                                            <TicketIcon className={`w-8 h-8 ${canAfford ? 'text-cyan-400' : 'text-slate-600'}`} />
                                            <span className={`font-bold text-lg ${canAfford ? 'text-amber-400' : 'text-slate-500'}`}>{reward.cost} PTS</span>
                                        </div>
                                        <h4 className="font-bold text-white text-lg mb-1">{reward.name}</h4>
                                        <p className="text-slate-400 text-sm mb-4">{reward.description}</p>
                                        <button 
                                            onClick={() => redeemReward(reward)}
                                            disabled={!canAfford}
                                            className={`w-full py-2 rounded-lg font-bold text-sm transition-all ${canAfford ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white hover:from-cyan-500 hover:to-blue-500 shadow-lg' : 'bg-slate-800 text-slate-500 cursor-not-allowed'}`}
                                        >
                                            {canAfford ? 'Échanger' : 'Points Insuffisants'}
                                        </button>
                                    </div>
                                )
                            })}
                        </div>
                    </div>

                 </div>
            </div>
        </section>
    );
  }

  return (
    <section id="account-auth" className="pt-32 pb-10 min-h-screen flex items-center justify-center">
      <div className="container mx-auto px-6 max-w-md">
          <div className="glass-panel p-8 rounded-2xl shadow-2xl relative overflow-hidden">
            {/* Décoration Cyber */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-blue-600"></div>
            
            <div className="text-center mb-8">
              <div className="inline-block bg-slate-800 p-4 rounded-full mb-4 border border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                <UserIcon className="w-10 h-10 text-cyan-400" />
              </div>
              <h2 className="text-3xl font-bold font-serif text-white neon-text">{isLogin ? 'Connexion' : 'Rejoindre l\'Elite'}</h2>
              <p className="text-slate-400 mt-2 text-sm">{isLogin ? 'Accédez à votre espace VIP.' : 'Créez votre compte et commencez à cumuler des points.'}</p>
            </div>

            {error && <div className="bg-red-500/10 text-red-400 p-3 rounded-lg mb-4 text-sm text-center border border-red-500/20 animate-pulse">{error}</div>}

            <form onSubmit={handleSubmit} className="space-y-5">
              {isLogin ? (
                <>
                  <div>
                    <label className="block text-xs uppercase tracking-wider font-bold text-slate-500 mb-1">Email</label>
                    <input type="text" required value={loginIdentifier} onChange={(e) => setLoginIdentifier(e.target.value)} className="block w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent outline-none transition-all" placeholder="Ex: client@email.com" />
                  </div>
                  <PasswordField id="password" label="MOT DE PASSE" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} style={{backgroundColor: '#020617', borderColor: '#334155', color: 'white'}} />
                </>
              ) : (
                <>
                  <div>
                    <label className="block text-xs uppercase tracking-wider font-bold text-slate-500 mb-1">Nom Complet</label>
                    <input type="text" required value={signupName} onChange={(e) => setSignupName(e.target.value)} className="block w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-cyan-500 outline-none" />
                  </div>
                  <PhoneField value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} />
                  <div>
                     <label className="block text-xs uppercase tracking-wider font-bold text-slate-500 mb-1">Email</label>
                     <input type="email" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} className="block w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-cyan-500 outline-none" />
                  </div>
                  <PasswordField id="signup-password" label="MOT DE PASSE" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} style={{backgroundColor: '#020617', borderColor: '#334155', color: 'white'}} />
                  <PasswordField id="confirm-password" label="CONFIRMER" value={signupConfirmPassword} onChange={(e) => setSignupConfirmPassword(e.target.value)} style={{backgroundColor: '#020617', borderColor: '#334155', color: 'white'}} />
                </>
              )}

              <button type="submit" disabled={isLoading} className="w-full py-4 rounded-xl font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-[0_0_20px_rgba(6,182,212,0.3)] transform hover:-translate-y-1 transition-all duration-300 uppercase tracking-wider">
                  {isLoading ? 'Chargement...' : (isLogin ? 'Se Connecter' : "Créer mon Compte")}
              </button>
            </form>

            <div className="mt-8 text-center">
                <button onClick={() => { setIsLogin(!isLogin); setError(null); }} className="text-sm text-slate-400 hover:text-cyan-400 transition-colors">
                  {isLogin ? 'Nouveau client ? Créer un compte' : 'Déjà membre ? Se connecter'}
                </button>
            </div>
          </div>
      </div>
    </section>
  );
};

export default ClientAccountPage;
