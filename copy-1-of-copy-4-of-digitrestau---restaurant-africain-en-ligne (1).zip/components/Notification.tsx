
import React from 'react';
import { NotificationType } from '../App';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import InformationCircleIcon from './icons/InformationCircleIcon';

interface NotificationProps {
    notifications: NotificationType[];
}

const Notification: React.FC<NotificationProps> = ({ notifications }) => {
    
    const icons = {
        success: <CheckCircleIcon className="w-6 h-6 text-green-500" />,
        error: <XCircleIcon className="w-6 h-6 text-red-500" />,
        info: <InformationCircleIcon className="w-6 h-6 text-blue-500" />,
    };

    const bgColors = {
        success: 'bg-green-50',
        error: 'bg-red-50',
        info: 'bg-blue-50',
    };

    return (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[100] w-full max-w-sm flex flex-col items-center space-y-2">
            {notifications.map(notification => (
                 <div
                    key={notification.id}
                    className={`flex items-center space-x-3 w-full p-4 rounded-xl shadow-lg animate-fade-in-down ${bgColors[notification.type]}`}
                >
                    <div className="flex-shrink-0">{icons[notification.type]}</div>
                    <p className="font-medium text-stone-800">{notification.message}</p>
                </div>
            ))}
            <style>{`
                @keyframes fade-in-down {
                    0% {
                        opacity: 0;
                        transform: translateY(-10px);
                    }
                    100% {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                .animate-fade-in-down {
                    animation: fade-in-down 0.3s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default Notification;
