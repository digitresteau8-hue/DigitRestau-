


import React, { useState, useEffect } from 'react';
import BoxIcon from './icons/BoxIcon';
import PlusIcon from './icons/PlusIcon';
import { Box } from './data';

const BoxCard: React.FC<{ box: Box }> = ({ box }) => (
  <div className="bg-stone-900 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out group transform hover:-translate-y-1 border border-white/5">
    <div className="p-6">
      <h3 className="text-xl font-bold font-serif text-white mb-2 group-hover:text-amber-500 transition-colors">{box.name}</h3>
      <p className="text-stone-400 mb-4">{box.description}</p>
      <div className="flex justify-between items-center">
        <span className="text-lg font-bold text-amber-500">{box.price.toLocaleString('fr-FR')} CFA</span>
        <button className="flex items-center space-x-2 bg-amber-700 text-white font-bold py-2 px-4 rounded-full hover:bg-amber-600 transition duration-300 shadow">
            <PlusIcon className="w-5 h-5" />
            <span>Ajouter</span>
        </button>
      </div>
    </div>
  </div>
);

interface ClientBoxesPageProps {
    boxes: Box[];
}

const ClientBoxesPage: React.FC<ClientBoxesPageProps> = ({ boxes }) => {
    return (
        <section id="boxes" className="pt-28 pb-10 min-h-screen">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <div className="inline-block bg-stone-900/80 p-4 rounded-full mb-4 border border-amber-500/30">
                        <BoxIcon className="w-10 h-10 text-amber-500" />
                    </div>
                    <h2 className="text-4xl font-bold font-serif text-white mb-4">Nos Boxs de Sauces</h2>
                    <p className="text-lg text-stone-400 max-w-2xl mx-auto">
                        Emportez un bout de notre cuisine chez vous avec nos sauces traditionnelles prêtes à l'emploi.
                    </p>
                </div>
                {boxes.length > 0 ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {boxes.map(box => (
                            <BoxCard key={box.id} box={box} />
                        ))}
                    </div>
                ) : (
                     <div className="text-center text-stone-500 bg-stone-900/80 backdrop-blur p-8 rounded-xl border border-white/5">
                        <p>Aucune box de sauce n'est disponible pour le moment.</p>
                    </div>
                )}
            </div>
        </section>
    );
};

export default ClientBoxesPage;