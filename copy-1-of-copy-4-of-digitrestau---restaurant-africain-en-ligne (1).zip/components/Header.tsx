
import React, { useState, useEffect } from 'react';
import { Page } from '../App';
import { Settings } from './data';
import SettingsModal from './SettingsModal';

interface ClientHeaderProps {
  currentPage: Page;
  setPage: (page: Page) => void;
  settings: Settings;
}

const Logo: React.FC = () => (
    <img src="https://i.ibb.co/WWHPStfL/1759863774896.png" alt="DigitRestau Logo" className="h-14 md:h-20 w-auto drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]" />
);

const ClientHeader: React.FC<ClientHeaderProps> = ({ currentPage, setPage, settings }) => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const isHomePage = currentPage === 'home';
    const headerClasses = `fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled || !isHomePage 
        ? 'bg-slate-950/80 backdrop-blur-lg border-b border-cyan-500/10 shadow-2xl shadow-cyan-900/10' 
        : 'bg-transparent'
    }`;
    
    const linkColor = 'text-slate-300 hover:text-cyan-400';

    const navLinks: { label: string; page: Page }[] = [
        { label: 'Menu', page: 'menu' },
        { label: 'Nos Services', page: 'traiteur' },
        { label: 'Nos Boxs', page: 'boxs' },
        { label: 'Contact', page: 'contact' },
    ];

    const NavLink: React.FC<{page: Page, label: string}> = ({ page, label }) => (
        <button 
            onClick={() => { setPage(page); setIsMenuOpen(false); }}
            className={`font-medium text-sm tracking-widest uppercase transition-all duration-300 pb-1 border-b-2 ${linkColor} ${currentPage === page ? 'border-cyan-500 text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.8)]' : 'border-transparent'}`}
        >
            {label}
        </button>
    );

    return (
        <>
            <header className={headerClasses}>
                <div className="container mx-auto px-6 py-3 flex justify-between items-center">
                    <button onClick={() => setPage('home')} aria-label="Page d'accueil" className="transform hover:scale-105 transition-transform duration-300">
                        <Logo />
                    </button>

                    <div className="hidden md:flex items-center space-x-8">
                        <nav className="items-center space-x-8 flex">
                            {navLinks.map(link => <NavLink key={link.page} {...link} />)}
                            <button
                                onClick={() => setIsSettingsModalOpen(true)}
                                className={`font-medium text-sm tracking-widest uppercase transition-all duration-300 pb-1 border-b-2 border-transparent ${linkColor}`}
                            >
                                Paramètres
                            </button>
                        </nav>
                        <a 
                            href="https://wa.me/22770032552" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold py-2 px-6 rounded-full transition-all duration-300 ease-in-out shadow-[0_0_15px_rgba(6,182,212,0.5)] border border-cyan-400/30 transform hover:-translate-y-1 hover:scale-105 hover:from-cyan-400 hover:to-blue-400 hover:shadow-[0_0_30px_rgba(34,211,238,0.8)] active:scale-95"
                        >
                            Commander
                        </a>
                    </div>

                    <div className="md:hidden">
                        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-cyan-400 focus:outline-none">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
                            </svg>
                        </button>
                    </div>
                </div>

                {isMenuOpen && (
                    <div className="md:hidden bg-slate-950/95 backdrop-blur-xl border-b border-cyan-500/20 animate-fade-in-down">
                        <div className="px-6 pt-4 pb-8 flex flex-col space-y-6 items-center">
                             {navLinks.map(link => (
                                <button key={link.page} onClick={() => { setPage(link.page as Page); setIsMenuOpen(false); }} className="text-slate-200 hover:text-cyan-400 block font-semibold text-lg tracking-wider uppercase">{link.label}</button>
                             ))}
                             <button
                                onClick={() => { setIsSettingsModalOpen(true); setIsMenuOpen(false); }}
                                className="text-slate-200 hover:text-cyan-400 block font-semibold text-lg tracking-wider uppercase"
                             >
                                 Paramètres
                             </button>
                            <a 
                                href="https://wa.me/22770032552" 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold py-4 px-6 rounded-full transition-all duration-300 text-center shadow-lg hover:from-cyan-500 hover:to-blue-500 hover:scale-105 hover:shadow-[0_0_20px_rgba(34,211,238,0.6)] active:scale-95"
                            >
                                Commander
                            </a>
                        </div>
                    </div>
                )}
            </header>
            <SettingsModal 
                isOpen={isSettingsModalOpen}
                onClose={() => setIsSettingsModalOpen(false)}
                settings={settings}
            />
             <style>{`
                @keyframes fade-in-down {
                    0% { opacity: 0; transform: translateY(-10px); }
                    100% { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-down {
                    animation: fade-in-down 0.3s ease-out forwards;
                }
            `}</style>
        </>
    );
};

export default ClientHeader;
