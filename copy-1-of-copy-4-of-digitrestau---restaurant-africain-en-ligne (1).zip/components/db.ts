

import { supabase } from './supabaseClient';
import { initialDishes, Dish, Order, initialOrders, Box, initialBoxes, Settings, initialSettings, Review } from './data';

// --- Helper pour vérifier si Supabase est prêt ---
const isSupabaseActive = () => supabase !== null;

// --- PLATS (DISHES) ---

export const getDishes = async (): Promise<Dish[]> => {
    if (!isSupabaseActive()) return initialDishes;
    
    try {
        const { data, error } = await supabase!.from('dishes').select('*');
        if (error) throw error;
        
        // AUTO-SEEDING: Si la base est vide, on injecte les données de démo automatiquement
        if (!data || data.length === 0) {
            console.log("🚀 Initialisation de la base de données : Injection des plats...");
            await saveDishes(initialDishes);
            return initialDishes;
        }

        // Conversion des données JSONB pour l'application
        return data.map((d: any) => ({
            ...d,
            reviews: typeof d.reviews === 'string' ? JSON.parse(d.reviews) : d.reviews || [],
            tags: typeof d.tags === 'string' ? JSON.parse(d.tags) : d.tags || [],
            allergens: typeof d.allergens === 'string' ? JSON.parse(d.allergens) : d.allergens || []
        }));
    } catch (error) {
        console.error("Erreur lors de la récupération des plats:", error);
        return initialDishes; // Repli sur les données locales en cas d'erreur réseau
    }
};

export const saveDishes = async (dishes: Dish[]): Promise<boolean> => {
    if (!isSupabaseActive()) return true;

    try {
        // On prépare les données pour Supabase (JSONB stringify)
        const formattedDishes = dishes.map(d => ({
            ...d,
            reviews: JSON.stringify(d.reviews || []),
            tags: JSON.stringify(d.tags || []),
            allergens: JSON.stringify(d.allergens || [])
        }));

        const { error } = await supabase!.from('dishes').upsert(formattedDishes);
        if (error) throw error;
        return true;
    } catch (error) {
        console.error("Erreur sauvegarde plats:", error);
        throw error;
    }
};

// --- COMMANDES (ORDERS) ---

export const getOrders = async (): Promise<Order[]> => {
    if (!isSupabaseActive()) return initialOrders;

    try {
        const { data, error } = await supabase!.from('orders').select('*').order('date', { ascending: false });
        if (error) throw error;
        
        // On ne seed PAS les commandes par défaut pour garder le dashboard propre
        if (!data || data.length === 0) return [];

        return data.map((o: any) => ({
            ...o,
            items: typeof o.items === 'string' ? JSON.parse(o.items) : o.items,
            deliveryCoords: typeof o.deliveryCoords === 'string' ? JSON.parse(o.deliveryCoords) : o.deliveryCoords
        }));
    } catch (error) {
        console.error("Erreur récupération commandes:", error);
        return initialOrders;
    }
};

export const saveOrders = async (orders: Order[]): Promise<boolean> => {
    if (!isSupabaseActive()) return true;
    
    try {
        const formattedOrders = orders.map(o => ({
            ...o,
            items: JSON.stringify(o.items),
            deliveryCoords: JSON.stringify(o.deliveryCoords)
        }));

        const { error } = await supabase!.from('orders').upsert(formattedOrders);
        if (error) throw error;
        return true;
    } catch (error) {
        console.error("Erreur sauvegarde commandes:", error);
        throw error;
    }
};

export const createOrder = async (order: Order): Promise<boolean> => {
    if (!isSupabaseActive()) return true;

    try {
        const formattedOrder = {
            ...order,
            items: JSON.stringify(order.items),
            deliveryCoords: JSON.stringify(order.deliveryCoords)
        };

        const { error } = await supabase!.from('orders').insert(formattedOrder);
        if(error) throw error;
        return true;
    } catch (error) {
        console.error("Erreur création commande:", error);
        throw error;
    }
};

// --- BOXS ---

export const getBoxes = async (): Promise<Box[]> => {
    if (!isSupabaseActive()) return initialBoxes;

    try {
        const { data, error } = await supabase!.from('boxes').select('*');
        if (error) throw error;

        // AUTO-SEEDING pour les Boxs
        if (!data || data.length === 0) {
            console.log("🚀 Initialisation : Injection des boxs...");
            await saveBoxes(initialBoxes);
            return initialBoxes;
        }

        return data;
    } catch (error) {
        return initialBoxes;
    }
};

export const saveBoxes = async (boxes: Box[]): Promise<boolean> => {
    if (!isSupabaseActive()) return true;
    const { error } = await supabase!.from('boxes').upsert(boxes);
    if (error) throw error;
    return true;
};

// --- PARAMÈTRES (SETTINGS) ---

export const getSettings = async (): Promise<Settings> => {
    if (!isSupabaseActive()) return initialSettings;

    try {
        const { data, error } = await supabase!.from('settings').select('*').eq('id', 'main').single();
        
        // AUTO-SEEDING pour les Paramètres
        if (error || !data) {
            console.log("🚀 Initialisation : Configuration des paramètres par défaut...");
            await saveSettings(initialSettings);
            return initialSettings;
        }

        return {
            paymentMethods: typeof data.paymentMethods === 'string' ? JSON.parse(data.paymentMethods) : data.paymentMethods,
            deliveryFees: typeof data.deliveryFees === 'string' ? JSON.parse(data.deliveryFees) : data.deliveryFees,
            openingHours: typeof data.openingHours === 'string' ? JSON.parse(data.openingHours) : data.openingHours,
            deliveryZones: typeof data.deliveryZones === 'string' ? JSON.parse(data.deliveryZones) : data.deliveryZones,
        };
    } catch (error) {
        return initialSettings;
    }
};

export const saveSettings = async (settings: Settings): Promise<boolean> => {
    if (!isSupabaseActive()) return true;
    
    try {
        const formattedSettings = {
            id: 'main',
            paymentMethods: JSON.stringify(settings.paymentMethods),
            deliveryFees: JSON.stringify(settings.deliveryFees),
            openingHours: JSON.stringify(settings.openingHours),
            deliveryZones: JSON.stringify(settings.deliveryZones)
        };

        const { error } = await supabase!.from('settings').upsert(formattedSettings);
        if (error) throw error;
        return true;
    } catch (error) {
        console.error("Erreur sauvegarde settings:", error);
        throw error;
    }
};

// --- AUTHENTIFICATION ---

export const authSignIn = async (email: string, password: string) => {
    if (!isSupabaseActive()) throw new Error("Supabase non configuré.");
    const { data, error } = await supabase!.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
}

export const authSignUp = async (email: string, password: string, metaData: any) => {
    if (!isSupabaseActive()) throw new Error("Supabase non configuré.");
    const { data, error } = await supabase!.auth.signUp({
        email,
        password,
        options: { data: metaData }
    });
    if (error) throw error;
    return data;
}

export const authUpdateUser = async (updates: { name?: string; phone?: string; avatarUrl?: string; isAdmin?: boolean }) => {
    // 1. Cas : Pas de Supabase (Mode Local pur)
    if (!isSupabaseActive()) {
        if (updates.avatarUrl) localStorage.setItem('digitrestau_local_avatar', updates.avatarUrl);
        return { data: { user: { user_metadata: updates } }, error: null };
    }
    
    // 2. Vérification de la session active réelle
    const { data: { session } } = await supabase!.auth.getSession();
    
    if (!session) {
        // 3. Cas : Supabase est là, mais l'Admin est connecté via le Code Secret (pas de session Auth)
        // On sauvegarde l'avatar localement pour simuler le succès sans erreur 401
        if (updates.avatarUrl) {
            localStorage.setItem('digitrestau_local_avatar', updates.avatarUrl);
        }
        // On retourne un succès simulé pour que l'interface mette à jour l'état
        return { data: { user: { user_metadata: updates } }, error: null };
    }
    
    // 4. Cas : Utilisateur/Admin connecté normalement via Email/MDP (Vraie Session)
    const { data, error } = await supabase!.auth.updateUser({
        data: updates
    });
    
    if (error) throw error;
    return data;
};

export const authSignOut = async () => {
    if (!isSupabaseActive()) return;
    await supabase!.auth.signOut();
}

export const authGetUser = async () => {
    if (!isSupabaseActive()) return null;
    const { data: { user } } = await supabase!.auth.getUser();
    return user;
}
