import React from 'react';
import { Page } from '../App';
import { CartItem } from './data';
import HomeIcon from './icons/HomeIcon';
import MenuIcon from './icons/MenuIcon';
import CartIcon from './icons/CartIcon';
import ClipboardListIcon from './icons/ClipboardListIcon';
import UserIcon from './icons/UserIcon';
import CateringIcon from './icons/CateringIcon';
import BoxIcon from './icons/BoxIcon';
import PhoneIcon from './icons/PhoneIcon';

interface ClientBottomNavProps {
  currentPage: Page;
  setPage: (page: Page) => void;
  cart: CartItem[];
}

interface NavItemProps {
  label: string;
  icon: React.ReactNode;
  page: Page;
  isActive: boolean;
  onClick: () => void;
  cartCount?: number;
}

const NavItem: React.FC<NavItemProps> = ({ label, icon, isActive, onClick, cartCount }) => (
  <button
    onClick={onClick}
    className={`relative flex flex-col items-center justify-center flex-shrink-0 w-20 pt-2 pb-1 transition-all duration-200 focus:outline-none ${isActive ? 'text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.6)]' : 'text-slate-500 hover:text-cyan-600'}`}
  >
    {icon}
    <span className={`text-[10px] font-medium mt-1 transition-opacity duration-200 uppercase tracking-wider ${isActive ? 'font-bold' : ''}`}>{label}</span>
     {cartCount && cartCount > 0 && (
        <span className="absolute top-0 right-1/2 translate-x-4 bg-red-600 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900 shadow-lg">
          {cartCount > 9 ? '9+' : cartCount}
        </span>
      )}
  </button>
);


const ClientBottomNav: React.FC<ClientBottomNavProps> = ({ currentPage, setPage, cart }) => {
  const totalItemsInCart = cart.reduce((total, item) => total + item.quantity, 0);

  const navItems = [
    { label: 'Accueil', icon: <HomeIcon className="w-6 h-6" />, page: 'home' },
    { label: 'Menu', icon: <MenuIcon className="w-6 h-6" />, page: 'menu' },
    { label: 'Panier', icon: <CartIcon className="w-6 h-6" />, page: 'cart', cartCount: totalItemsInCart },
    { label: 'Traiteur', icon: <CateringIcon className="w-6 h-6" />, page: 'traiteur' },
    { label: 'Boxs', icon: <BoxIcon className="w-6 h-6" />, page: 'boxs' },
    { label: 'Commandes', icon: <ClipboardListIcon className="w-6 h-6" />, page: 'commande' },
    { label: 'Compte', icon: <UserIcon className="w-6 h-6" />, page: 'compte' },
    { label: 'Contact', icon: <PhoneIcon className="w-6 h-6" />, page: 'contact' },
  ];
  
  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 bg-slate-950/90 backdrop-blur-xl border-t border-white/5 shadow-[0_-5px_20px_rgba(0,0,0,0.3)] z-40 h-16">
          <div className="overflow-x-auto whitespace-nowrap h-full flex items-center px-2 scrollbar-hide">
              <div className="inline-flex space-x-1 mx-auto">
                  {navItems.map(item => (
                    <NavItem
                        key={item.page}
                        label={item.label}
                        icon={item.icon}
                        page={item.page as Page}
                        isActive={currentPage === item.page}
                        onClick={() => setPage(item.page as Page)}
                        cartCount={item.cartCount}
                    />
                  ))}
              </div>
          </div>
      </div>
      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </>
  );
};

export default ClientBottomNav;