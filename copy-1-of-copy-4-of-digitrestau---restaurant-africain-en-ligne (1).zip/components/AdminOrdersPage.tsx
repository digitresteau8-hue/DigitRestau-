
import React, { useState, useRef, useEffect } from 'react';
import ClipboardListIcon from './icons/ClipboardListIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import TrashIcon from './icons/TrashIcon';
import DownloadIcon from './icons/DownloadIcon';
import UploadIcon from './icons/UploadIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';
import PrinterIcon from './icons/PrinterIcon';
import { Order, OrderStatus, OrderItem } from './data';
import MapPinIcon from './icons/MapPinIcon';

declare const L: any;

const statusStyles: { [key in OrderStatus]: string } = {
    'Confirmée': 'border-purple-500 bg-purple-50 text-purple-700 focus:ring-purple-500',
    'En préparation': 'border-yellow-500 bg-yellow-50 text-yellow-700 focus:ring-yellow-500',
    'Prête': 'border-cyan-500 bg-cyan-50 text-cyan-700 focus:ring-cyan-500',
    'En cours de livraison': 'border-blue-500 bg-blue-50 text-blue-700 focus:ring-blue-500',
    'Livrée': 'border-green-500 bg-green-50 text-green-700 focus:ring-green-500',
    'Annulée': 'border-red-500 bg-red-50 text-red-700 focus:ring-red-500',
};

const RESTAURANT_LOCATION = { lat: 13.5136, lng: 2.1154 };
const SIMULATION_DURATION_MS = 20000;
const SIMULATION_INTERVAL_MS = 100;

interface AdminOrdersPageProps {
    showNotification: (message: string, type: 'success' | 'error' | 'info') => void;
    orders: Order[];
    onUpdateOrders: (orders: Order[]) => void;
}

const AdminOrdersPage: React.FC<AdminOrdersPageProps> = ({ showNotification, orders, onUpdateOrders }) => {
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState<string | null>(null);
  const [statusChangeConfirm, setStatusChangeConfirm] = useState<{orderId: string, newStatus: OrderStatus, oldStatus: OrderStatus} | null>(null);
  const [filterStatus, setFilterStatus] = useState<OrderStatus | 'Toutes'>('Toutes');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);
  const [driverLocation, setDriverLocation] = useState(RESTAURANT_LOCATION);
  const [simulationProgress, setSimulationProgress] = useState(0);
  const simulationIntervalRef = useRef<number | null>(null);


  const handleStatusChangeAttempt = (orderId: string, newStatus: OrderStatus) => {
    const order = orders.find(o => o.id === orderId);
    if (order && order.status !== newStatus) {
        setStatusChangeConfirm({ orderId, newStatus, oldStatus: order.status });
    }
  };

  const confirmStatusChange = () => {
    if (statusChangeConfirm) {
      const updatedOrders = orders.map(order =>
          order.id === statusChangeConfirm.orderId 
            ? { ...order, status: statusChangeConfirm.newStatus } 
            : order
        );
      onUpdateOrders(updatedOrders);
      showNotification(`Statut de la commande #${statusChangeConfirm.orderId} mis à jour.`, 'success');
      setStatusChangeConfirm(null);
    }
  };

  const cancelStatusChange = () => {
    setStatusChangeConfirm(null);
  };
  
  const toggleExpand = (orderId: string) => {
    setExpandedOrderId(prevId => (prevId === orderId ? null : orderId));
  };
  
  const handleDelete = (orderId: string) => {
    const updatedOrders = orders.filter(order => order.id !== orderId);
    onUpdateOrders(updatedOrders);
    setShowDeleteConfirmModal(null);
    showNotification(`Commande #${orderId} supprimée.`, 'success');
  };

  const handleNotifyClient = (order: Order) => {
    const message = `Bonjour ${order.customerName}, votre commande DigitRestau n°${order.id} est maintenant : *${order.status}*. Merci pour votre confiance !`;
    const whatsappUrl = `https://wa.me/${order.customerPhone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handlePrintTicket = (order: Order) => {
      const printWindow = window.open('', '', 'width=400,height=600');
      if (printWindow) {
          const itemsHtml = order.items.map(item => `
              <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                  <span>${item.quantity} x ${item.name}</span>
                  <span>${(item.price * item.quantity).toLocaleString('fr-FR')}</span>
              </div>
          `).join('');

          printWindow.document.write(`
              <html>
              <head>
                  <title>Ticket #${order.id}</title>
                  <style>
                      body { font-family: 'Courier New', monospace; font-size: 12px; padding: 20px; width: 300px; margin: 0 auto; background: white; color: black; }
                      .header { text-align: center; margin-bottom: 20px; border-bottom: 1px dashed #000; padding-bottom: 10px; }
                      .logo-img { width: 80px; height: auto; margin-bottom: 10px; }
                      .logo-text { font-size: 16px; font-weight: bold; margin-bottom: 5px; }
                      .info { margin-bottom: 15px; }
                      .items { border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
                      .total { font-size: 16px; font-weight: bold; text-align: right; margin-top: 10px; }
                      .footer { text-align: center; margin-top: 20px; font-size: 10px; }
                  </style>
              </head>
              <body>
                  <div class="header">
                      <img src="https://i.ibb.co/WWHPStfL/1759863774896.png" alt="Logo" class="logo-img" />
                      <div class="logo-text">DIGITRESTAU</div>
                      <div>Niamey, Niger</div>
                      <div>+227 70 03 25 52</div>
                  </div>
                  <div class="info">
                      <div><strong>Commande #${order.id}</strong></div>
                      <div>Date: ${new Date(order.date).toLocaleDateString('fr-FR')} ${new Date(order.date).toLocaleTimeString('fr-FR')}</div>
                      <div style="margin-top: 10px;"><strong>Client:</strong> ${order.customerName}</div>
                      <div><strong>Tél:</strong> ${order.customerPhone}</div>
                      <div><strong>Adresse:</strong> ${order.deliveryAddress}</div>
                  </div>
                  <div class="items">
                      ${itemsHtml}
                  </div>
                  <div style="display: flex; justify-content: space-between;">
                      <span>Livraison:</span>
                      <span>${order.deliveryFee.toLocaleString('fr-FR')}</span>
                  </div>
                  <div class="total">
                      TOTAL: ${order.total.toLocaleString('fr-FR')} CFA
                  </div>
                  <div style="text-align: center; margin-top: 10px;">
                    Paiement: ${order.paymentMethod}
                  </div>
                  <div class="footer">
                      Merci de votre commande !<br/>
                      Bon appétit.
                  </div>
                  <script>
                    window.onload = function() { window.print(); window.close(); }
                  </script>
              </body>
              </html>
          `);
          printWindow.document.close();
      }
  };
  
  const handleStopTracking = () => {
        if (simulationIntervalRef.current) {
            clearInterval(simulationIntervalRef.current);
            simulationIntervalRef.current = null;
        }
        setTrackingOrder(null);
  };

  const handleStartTracking = (order: Order) => {
    if (!order.deliveryCoords) {
        showNotification("Les coordonnées de livraison ne sont pas disponibles pour cette commande.", "error");
        return;
    }
    setTrackingOrder(order);
    setDriverLocation(RESTAURANT_LOCATION);
    setSimulationProgress(0);

    const startTime = Date.now();

    simulationIntervalRef.current = window.setInterval(() => {
        const elapsedTime = Date.now() - startTime;
        const progress = Math.min(elapsedTime / SIMULATION_DURATION_MS, 1);
        
        const destination = order.deliveryCoords!;
        const newLat = RESTAURANT_LOCATION.lat + (destination.lat - RESTAURANT_LOCATION.lat) * progress;
        const newLng = RESTAURANT_LOCATION.lng + (destination.lng - RESTAURANT_LOCATION.lng) * progress;

        setDriverLocation({ lat: newLat, lng: newLng });
        setSimulationProgress(progress);
        
        if (progress >= 1) {
            handleStopTracking();
            
            const updatedOrders = orders.map(o => o.id === order.id ? { ...o, status: 'Livrée' as OrderStatus } : o);
            onUpdateOrders(updatedOrders);
            
            showNotification(`La commande #${order.id} a été livrée avec succès!`, 'success');
        }
    }, SIMULATION_INTERVAL_MS);
  };

  useEffect(() => {
    return () => {
        if (simulationIntervalRef.current) {
            clearInterval(simulationIntervalRef.current);
        }
    };
  }, []);


  const filteredOrders = orders.filter(order => filterStatus === 'Toutes' || order.status === filterStatus);

  const handleExportCSV = () => {
    if (filteredOrders.length === 0) {
        showNotification("Aucune commande à exporter pour le filtre sélectionné.", 'info');
        return;
    }

    const headers = [
        "ID Commande", "Date", "Heure", "Nom Client", "Téléphone Client",
        "Adresse Livraison", "Articles", "Frais Livraison", "Total", "Statut", "Méthode Paiement"
    ];

    const rows = filteredOrders.map(order => {
        const date = new Date(order.date);
        const formattedDate = date.toLocaleDateString('fr-FR');
        const formattedTime = date.toLocaleTimeString('fr-FR');
        const itemsString = order.items.map(item => `${item.quantity}x ${item.name}`).join('; ');

        return [
            order.id,
            formattedDate,
            formattedTime,
            `"${order.customerName.replace(/"/g, '""')}"`,
            order.customerPhone,
            `"${order.deliveryAddress.replace(/"/g, '""')}"`,
            `"${itemsString.replace(/"/g, '""')}"`,
            order.deliveryFee,
            order.total,
            order.status,
            order.paymentMethod
        ].join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," 
        + headers.join(',') + '\n' 
        + rows.join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const today = new Date().toISOString().slice(0, 10);
    link.setAttribute("download", `export-commandes-digitrestau-${today}.csv`);
    document.body.appendChild(link); 

    link.click();
    document.body.removeChild(link);
    showNotification("Exportation CSV terminée.", 'success');
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = (e) => {
            const text = e.target?.result as string;
            try {
                const lines = text.split(/\r\n|\n/).filter(line => line.trim() !== '');
                if (lines.length < 2) {
                    throw new Error("Le fichier CSV est vide ou ne contient que l'en-tête.");
                }

                const headers = lines[0].split(',').map(h => h.trim());
                if (headers[0] !== 'ID Commande' || headers[9] !== 'Statut') {
                    throw new Error("L'en-tête du fichier CSV ne correspond pas au format attendu.");
                }

                const newOrders: Order[] = lines.slice(1).map((line, index) => {
                    const values = line.match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g)?.map(v => v.replace(/"/g, '')) || [];

                    if (values.length < headers.length) {
                         throw new Error(`La ligne ${index + 2} est malformée ou incomplète.`);
                    }

                    const [id, dateStr, timeStr, customerName, customerPhone, deliveryAddress, itemsStr, deliveryFee, total, status, paymentMethod] = values;

                    const [day, month, year] = dateStr.split('/');
                    const isoDate = new Date(`${year}-${month}-${day}T${timeStr}`).toISOString();
                    
                    const items = itemsStr.split(';').map((itemStr, itemIndex) => {
                        const match = itemStr.trim().match(/(\d+)\s*x\s*(.*)/);
                        if (match) {
                            return {
                                id: `imported-${id}-${itemIndex}`,
                                name: match[2].trim(),
                                quantity: parseInt(match[1], 10),
                                price: 0, 
                            };
                        }
                        return null;
                    }).filter((item): item is OrderItem => item !== null);

                    return {
                        id,
                        date: isoDate,
                        customerName,
                        customerId: `imported-${customerName.replace(/\s/g, '')}`,
                        customerPhone,
                        deliveryAddress,
                        items,
                        deliveryFee: parseFloat(deliveryFee),
                        total: parseFloat(total),
                        status: status as OrderStatus,
                        paymentMethod,
                    };
                });
                
                const ordersMap = new Map(orders.map(o => [o.id, o]));
                newOrders.forEach(order => ordersMap.set(order.id, order));
                onUpdateOrders(Array.from(ordersMap.values()));

                showNotification(`${newOrders.length} commandes importées/mises à jour avec succès.`, 'success');
            } catch (error) {
                 if (error instanceof Error) {
                    showNotification(`Erreur d'importation: ${error.message}`, 'error');
                 } else {
                    showNotification(`Une erreur inconnue est survenue.`, 'error');
                 }
            } finally {
                if(event.target) event.target.value = ""; 
            }
        };

        reader.onerror = () => {
             showNotification("Impossible de lire le fichier.", 'error');
        };
        
        reader.readAsText(file, 'UTF-8');
    };
  
  const statusCounts = orders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
  }, {} as Record<OrderStatus, number>);

  const statuses: (OrderStatus | 'Toutes')[] = ['Toutes', 'Confirmée', 'En préparation', 'Prête', 'En cours de livraison', 'Livrée', 'Annulée'];


  return (
    <div>
      <h1 className="text-3xl font-bold font-serif text-stone-900 mb-6">Gestion des Commandes</h1>
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <div className="flex flex-col md:flex-row justify-between md:items-center mb-4 gap-4">
            <h2 className="text-xl font-bold text-gray-800">Liste des Commandes</h2>
            <div className="flex items-center gap-2">
                 <input type="file" ref={fileInputRef} onChange={handleImportCSV} accept=".csv" className="hidden" />
                 <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center space-x-2 bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300 shadow-sm"
                >
                    <UploadIcon className="w-5 h-5" />
                    <span>Importer</span>
                </button>
                 <button 
                    onClick={handleExportCSV}
                    className="flex items-center justify-center space-x-2 bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition duration-300 shadow-sm"
                >
                    <DownloadIcon className="w-5 h-5" />
                    <span>Exporter</span>
                </button>
            </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4 border-b pb-4">
            {statuses.map(status => {
                const count = status === 'Toutes' ? orders.length : (statusCounts[status] || 0);
                return (
                    <button
                        key={status}
                        onClick={() => setFilterStatus(status)}
                        className={`px-3 py-1 text-sm font-semibold rounded-full transition-colors duration-200 ${
                            filterStatus === status 
                                ? 'bg-amber-700 text-white shadow' 
                                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                    >
                        {status} <span className="ml-1 bg-white/20 text-xs font-bold rounded-full px-1.5 py-0.5">{count}</span>
                    </button>
                )
            })}
        </div>

        <div className="space-y-4">
          {filteredOrders.length > 0 ? (
            filteredOrders.map(order => {
              const subTotal = order.items.reduce((acc, item) => acc + item.price * item.quantity, 0);
              return (
              <div key={order.id} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-50 p-4 grid grid-cols-2 md:grid-cols-6 gap-4 items-center">
                  <div className="col-span-2 md:col-span-1">
                    <span className="font-bold text-gray-800">#{order.id}</span>
                    <span className="block text-sm text-gray-500">{order.customerName}</span>
                  </div>
                  <div className="hidden md:block">
                     <span className="font-semibold text-gray-700">{new Date(order.date).toLocaleDateString('fr-FR')}</span>
                     <span className="block text-sm text-gray-500">{new Date(order.date).toLocaleTimeString('fr-FR')}</span>
                  </div>
                   <div className="text-right md:text-left">
                     <span className="font-bold text-lg text-amber-800">
                        {order.total.toLocaleString('fr-FR')} CFA
                     </span>
                  </div>
                  <div className="md:col-span-2">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChangeAttempt(order.id, e.target.value as OrderStatus)}
                      className={`w-full text-sm font-bold p-2 rounded-md border-2 transition-colors ${statusStyles[order.status]}`}
                    >
                      <option value="Confirmée">Confirmée</option>
                      <option value="En préparation">En préparation</option>
                      <option value="Prête">Prête</option>
                      <option value="En cours de livraison">En cours de livraison</option>
                      <option value="Livrée">Livrée</option>
                      <option value="Annulée">Annulée</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-end space-x-1">
                    <button
                        onClick={() => handlePrintTicket(order)}
                        className="p-2 hover:bg-stone-200 rounded-full transition-colors text-gray-600 hover:text-gray-900"
                        aria-label="Imprimer le ticket"
                        title="Imprimer le Ticket"
                    >
                        <PrinterIcon className="w-5 h-5" />
                    </button>
                    {order.status === 'En cours de livraison' && (
                        <button
                            onClick={() => handleStartTracking(order)}
                            className="p-2 hover:bg-blue-100 rounded-full transition-colors text-gray-500 hover:text-blue-600"
                            aria-label={`Suivre la livraison pour la commande ${order.id}`}
                            title="Suivre la livraison"
                        >
                            <MapPinIcon className="w-5 h-5" />
                        </button>
                    )}
                    <button
                        onClick={() => handleNotifyClient(order)}
                        className="p-2 hover:bg-green-100 rounded-full transition-colors text-gray-500 hover:text-green-600"
                        aria-label={`Notifier le client pour la commande ${order.id}`}
                        title="Notifier le client via WhatsApp"
                    >
                        <WhatsAppIcon className="w-5 h-5" />
                    </button>
                     <button 
                        onClick={() => setShowDeleteConfirmModal(order.id)} 
                        className="p-2 hover:bg-red-100 rounded-full transition-colors text-gray-500 hover:text-red-600"
                        aria-label={`Supprimer la commande ${order.id}`}
                        title="Supprimer la commande"
                     >
                        <TrashIcon className="w-5 h-5" />
                    </button>
                    <button 
                        onClick={() => toggleExpand(order.id)} 
                        className="p-2 hover:bg-gray-200 rounded-full transition-colors"
                        aria-label={`Détails de la commande ${order.id}`}
                    >
                      <ChevronRightIcon className={`w-5 h-5 text-gray-600 transition-transform ${expandedOrderId === order.id ? 'rotate-90' : ''}`} />
                    </button>
                  </div>
                </div>
                {expandedOrderId === order.id && (
                   <div className="p-6 border-t border-gray-200 bg-white">
                        <div className="grid md:grid-cols-2 gap-x-8 gap-y-4">
                            <div>
                                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Client & Livraison</h4>
                                <p className="font-bold text-gray-800">{order.customerName}</p>
                                <p className="text-gray-600">{order.customerPhone}</p>
                                <p className="text-gray-600">{order.deliveryAddress}</p>
                            </div>
                            <div>
                                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Articles</h4>
                                <ul className="space-y-1 text-gray-700">
                                   {order.items.map(item => (
                                       <li key={item.id} className="flex justify-between">
                                           <span>{item.quantity} x {item.name}</span>
                                           <span className="font-mono">{(item.price * item.quantity).toLocaleString('fr-FR')}</span>
                                       </li>
                                   ))}
                                </ul>
                            </div>
                            <div className="md:col-span-2 pt-4 mt-4 border-t">
                                 <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Paiement</h4>
                                        <p className="text-gray-700 font-semibold">{order.paymentMethod}</p>
                                    </div>
                                    <div className="text-right">
                                        <div className="flex justify-between space-x-4"><span className="text-gray-600">Sous-total:</span> <span className="font-mono w-24 text-right">{subTotal.toLocaleString('fr-FR')} CFA</span></div>
                                        <div className="flex justify-between space-x-4"><span className="text-gray-600">Livraison:</span> <span className="font-mono w-24 text-right">{order.deliveryFee.toLocaleString('fr-FR')} CFA</span></div>
                                        <div className="flex justify-between space-x-4 font-bold text-lg mt-1"><span className="text-gray-800">Total:</span> <span className="font-mono w-24 text-right text-amber-800">{order.total.toLocaleString('fr-FR')} CFA</span></div>
                                    </div>
                                 </div>
                            </div>
                        </div>
                   </div>
                )}
              </div>
              );
            })
          ) : (
            <div className="text-center py-10 text-gray-500">
              <ClipboardListIcon className="w-12 h-12 mx-auto mb-2" />
              <p>Aucune commande ne correspond au filtre "{filterStatus}".</p>
            </div>
          )}
        </div>
      </div>

      {trackingOrder && (
        <TrackingModal
            order={trackingOrder}
            driverLocation={driverLocation}
            progress={simulationProgress}
            onClose={handleStopTracking}
        />
      )}

      {showDeleteConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h3 className="text-lg font-bold text-gray-900">Confirmer la Suppression</h3>
                <p className="mt-2 text-sm text-gray-600">
                    Êtes-vous sûr de vouloir supprimer la commande <strong>#{showDeleteConfirmModal}</strong> ? Cette action est irréversible.
                </p>
                <div className="mt-6 flex justify-end space-x-3">
                    <button 
                        onClick={() => setShowDeleteConfirmModal(null)}
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition"
                    >
                        Annuler
                    </button>
                    <button 
                        onClick={() => handleDelete(showDeleteConfirmModal)}
                        className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition"
                    >
                        Supprimer
                    </button>
                </div>
            </div>
        </div>
      )}

      {statusChangeConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h3 className="text-lg font-bold text-gray-900">Confirmer le Changement de Statut</h3>
                <p className="mt-2 text-sm text-gray-600">
                    Voulez-vous vraiment changer le statut de la commande <strong>#{statusChangeConfirm.orderId}</strong> de "{statusChangeConfirm.oldStatus}" à "{statusChangeConfirm.newStatus}" ?
                </p>
                <div className="mt-6 flex justify-end space-x-3">
                    <button 
                        onClick={cancelStatusChange}
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition"
                    >
                        Annuler
                    </button>
                    <button 
                        onClick={confirmStatusChange}
                        className="px-4 py-2 bg-amber-700 text-white rounded-md hover:bg-amber-800 transition"
                    >
                        Confirmer
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

interface InteractiveMapProps {
    order: Order;
    driverLocation: { lat: number; lng: number };
}

const InteractiveMap: React.FC<InteractiveMapProps> = ({ order, driverLocation }) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapRef = useRef<any>(null);
    const driverMarkerRef = useRef<any>(null);
    const isMapInitialized = useRef(false);

    useEffect(() => {
        if (!mapContainerRef.current || isMapInitialized.current || !order.deliveryCoords) return;

        const destination = order.deliveryCoords;
        mapRef.current = L.map(mapContainerRef.current).setView(RESTAURANT_LOCATION, 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(mapRef.current);

        const restaurantIcon = L.icon({
            iconUrl: 'https://i.ibb.co/WWHPStfL/1759863774896.png',
            iconSize: [40, 40],
            iconAnchor: [20, 20],
            popupAnchor: [0, -20],
            className: 'bg-white rounded-full shadow-lg'
        });

        const homeIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 text-red-600"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955a.75.75 0 011.06 0l8.955 8.955M3 13.5V21h6v-6h6v6h6v-7.5M12 3v5.25" /></svg>`;
        const homeIcon = L.divIcon({
            html: `<div class="p-1 bg-white rounded-full shadow-md flex items-center justify-center">${homeIconSVG}</div>`,
            className: '',
            iconSize: [32, 32],
            iconAnchor: [16, 32],
        });
        
        const driverIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 text-blue-600"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2.14-1.284A2 2 0 016.14 15H13zm-3-5h4M13 8h4m-5 8H5.86a2 2 0 01-1.79-.894L3 13m15 4a2 2 0 10-4 0 2 2 0 004 0z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h-1a2 2 0 10-4 0h1m4 0h1m-1 0v-4.14a2 2 0 00-.86-1.638l-2.28-1.52a2 2 0 00-2.02 0L9 11.222M19 17h2a1 1 0 001-1v-3.333a1 1 0 00-.57-.905l-3-1.667a1 1 0 00-.86.055L14 11.222"></path></svg>`;
        const driverIcon = L.divIcon({
            html: `<div class="p-1 bg-white rounded-full shadow-md flex items-center justify-center">${driverIconSVG}</div>`,
            className: 'transition-all duration-100 ease-linear',
            iconSize: [40, 40],
            iconAnchor: [20, 20],
        });

        L.marker(RESTAURANT_LOCATION, { icon: restaurantIcon }).addTo(mapRef.current).bindPopup('<b>DigitRestau</b>');
        L.marker(destination, { icon: homeIcon }).addTo(mapRef.current).bindPopup(`<b>${order.customerName}</b>`);
        L.polyline([RESTAURANT_LOCATION, destination], { color: 'blue', dashArray: '5, 10' }).addTo(mapRef.current);
        
        driverMarkerRef.current = L.marker(driverLocation, { icon: driverIcon, zIndexOffset: 1000 }).addTo(mapRef.current);

        mapRef.current.fitBounds([RESTAURANT_LOCATION, destination], { padding: [50, 50] });
        isMapInitialized.current = true;
        
        return () => {
            if (mapRef.current) {
                mapRef.current.remove();
                mapRef.current = null;
                isMapInitialized.current = false;
            }
        };
    }, [order.id]); 

    useEffect(() => {
        if (driverMarkerRef.current) {
            driverMarkerRef.current.setLatLng(driverLocation);
        }
    }, [driverLocation]);

    return <div ref={mapContainerRef} className="w-full h-80 rounded-lg" />;
};

interface TrackingModalProps {
    order: Order;
    driverLocation: { lat: number; lng: number };
    progress: number;
    onClose: () => void;
}

const TrackingModal: React.FC<TrackingModalProps> = ({ order, driverLocation, progress, onClose }) => {
    const etaSeconds = Math.round((SIMULATION_DURATION_MS / 1000) * (1 - progress));

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b flex justify-between items-center">
                    <h3 className="text-lg font-bold text-gray-900">Suivi de la Commande #{order.id}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button>
                </div>
                <div className="p-4">
                    {order.deliveryCoords ? (
                         <InteractiveMap order={order} driverLocation={driverLocation} />
                    ) : (
                        <div className="h-80 flex items-center justify-center bg-gray-100 rounded-lg">
                            <p className="text-gray-500">Les coordonnées pour cette commande ne sont pas disponibles.</p>
                        </div>
                    )}
                     <div className="mt-4 text-center">
                        <p className="text-gray-700">Adresse de livraison: <strong>{order.deliveryAddress}</strong></p>
                        <div className="mt-2 h-2.5 w-full bg-gray-200 rounded-full">
                            <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${progress * 100}%` }}></div>
                        </div>
                        <p className="text-sm font-semibold text-gray-600 mt-1">
                            {progress < 1 ? `Arrivée estimée dans ${etaSeconds}s...` : 'Livreur arrivé !'}
                        </p>
                    </div>
                </div>
            </div>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in {
                    animation: fade-in 0.3s ease-out forwards;
                }
            `}</style>
        </div>
    )
}

export default AdminOrdersPage;
