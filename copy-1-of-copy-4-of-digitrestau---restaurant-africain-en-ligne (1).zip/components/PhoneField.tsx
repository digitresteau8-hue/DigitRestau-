
import React, { useState } from 'react';

interface PhoneFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
    error?: string | null;
}

const PhoneField: React.FC<PhoneFieldProps> = ({ error: propError, ...props }) => {
    const [internalError, setInternalError] = useState<string | null>(null);

    const validatePhone = (value: string) => {
        if (value && !/^\d{8}$/.test(value)) {
            setInternalError("Le numéro doit contenir exactement 8 chiffres.");
            return false;
        }
        setInternalError(null);
        return true;
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        validatePhone(e.target.value);
        if (props.onBlur) {
            props.onBlur(e);
        }
    };
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (internalError) {
            setInternalError(null);
        }
        if (props.onChange) {
            props.onChange(e);
        }
    };

    const error = propError || internalError;
    const inputBorderColor = error ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-amber-600 focus:border-amber-600';
    const spanBorderColor = error ? 'border-red-500' : 'border-gray-300';


    return (
        <div>
            <label htmlFor="phone" className="block text-sm font-medium text-stone-700">Téléphone</label>
            <div className="mt-1 flex rounded-md shadow-sm">
                 <span className={`inline-flex items-center px-3 rounded-l-md border bg-stone-100 text-stone-800 font-semibold sm:text-sm ${spanBorderColor}`}>
                    🇳🇪 +227
                </span>
                <input
                    type="tel"
                    id="phone"
                    className={`-ml-px relative flex-1 min-w-0 block w-full px-3 py-2 rounded-r-md ${inputBorderColor}`}
                    placeholder="70032552"
                    required
                    {...props}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    aria-invalid={!!error}
                    aria-describedby={error ? "phone-error" : undefined}
                />
            </div>
            {error && <p id="phone-error" className="mt-2 text-sm text-red-600">{error}</p>}
        </div>
    );
};

export default PhoneField;
