
import React from 'react';
import PhoneIcon from './icons/PhoneIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';
import ClockIcon from './icons/ClockIcon';
import MapPinIcon from './icons/MapPinIcon';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';

const ContactInfoItem: React.FC<{ icon: React.ReactNode; children: React.ReactNode }> = ({ icon, children }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 mt-1 text-orange-600">{icon}</div>
        <div>{children}</div>
    </div>
);

const SocialLink: React.FC<{ href: string; icon: React.ReactNode; label: string }> = ({ href, icon, label }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-3 text-stone-600 hover:text-orange-600 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">
        {icon}
        <span className="font-medium">{label}</span>
    </a>
);


const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold font-serif text-stone-900 mb-4">Contactez-Nous & Commandez</h2>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto">
            Une question ? Une envie ? Nous sommes à votre écoute pour prendre votre commande.
          </p>
        </div>
        <div className="bg-stone-50 p-8 md:p-12 rounded-xl shadow-lg grid md:grid-cols-2 gap-12">
            <div className="space-y-8">
                <ContactInfoItem icon={<PhoneIcon className="w-6 h-6" />}>
                    <p className="text-lg font-semibold text-stone-800">Par Téléphone</p>
                    <a href="tel:+22770032552" className="block text-stone-600 hover:text-orange-700 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">_227 70 03 25 52</a>
                    <a href="tel:+22774441621" className="block text-stone-600 hover:text-orange-700 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">_227 74 44 16 21</a>
                </ContactInfoItem>

                 <ContactInfoItem icon={<WhatsAppIcon className="w-6 h-6" />}>
                    <p className="text-lg font-semibold text-stone-800">Via WhatsApp</p>
                    <a href="https://wa.me/22770032552" target="_blank" rel="noopener noreferrer" className="block text-stone-600 hover:text-orange-700 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">_227 70 03 25 52</a>
                    <a href="https://wa.me/22774441621" target="_blank" rel="noopener noreferrer" className="block text-stone-600 hover:text-orange-700 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">_227 74 44 16 21</a>
                </ContactInfoItem>
                
                 <ContactInfoItem icon={<ClockIcon className="w-6 h-6" />}>
                    <p className="text-lg font-semibold text-stone-800">Horaires d'Ouverture</p>
                    <p className="text-stone-600">7/7 jours, de 09h à 22h</p>
                </ContactInfoItem>

                <ContactInfoItem icon={<MapPinIcon className="w-6 h-6" />}>
                    <p className="text-lg font-semibold text-stone-800">Emplacement</p>
                    <p className="text-stone-600">Niamey, Niger (Service 100% en ligne)</p>
                </ContactInfoItem>
            </div>
            <div className="space-y-8">
                <div>
                    <h3 className="text-2xl font-bold font-serif text-stone-900 mb-6">Suivez nos aventures culinaires</h3>
                    <div className="space-y-4">
                        <SocialLink href="#" icon={<FacebookIcon className="w-7 h-7" />} label="@Allorestau" />
                        <SocialLink href="#" icon={<InstagramIcon className="w-7 h-7" />} label="@digitrestau" />
                    </div>
                </div>
                 <div>
                    <h3 className="text-2xl font-bold font-serif text-stone-900 mb-6">Partenaire de Livraison</h3>
                    <div className="flex items-center space-x-4">
                       <img src="https://picsum.photos/seed/delivery/60/60" alt="Billo Express logo" className="rounded-full" />
                       <div>
                           <p className="text-lg font-semibold text-stone-800">Billo Express</p>
                           <p className="text-stone-600">Rapide - Fiable - Sécurisé</p>
                           <a href="tel:+22792080822" className="text-stone-600 hover:text-orange-700 transition-transform duration-300 ease-in-out transform hover:-translate-y-1">_227 92 08 08 22</a>
                       </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;