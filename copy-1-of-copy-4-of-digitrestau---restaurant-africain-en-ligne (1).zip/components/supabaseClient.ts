
import { createClient } from '@supabase/supabase-js';

// =========================================================================
// 🚀 GESTION INTELLIGENTE DE LA CONNEXION
// =========================================================================

// 1. Priorité : Variables d'environnement (Pour Vercel)
const envUrl = (import.meta as any).env?.VITE_SUPABASE_URL;
const envKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;

// 2. Priorité : Clés manuelles (Si vous modifiez le code)
// Remplacez les valeurs ci-dessous UNIQUEMENT si vous savez ce que vous faites.
const HARDCODED_URL = 'VOTRE_URL_SUPABASE_ICI'; 
const HARDCODED_KEY = 'VOTRE_CLE_ANON_PUBLIC_ICI'; 

// 3. Priorité : Mémoire du Navigateur (Pour connexion via le Dashboard)
const localUrl = localStorage.getItem('digitrestau_supabase_url');
const localKey = localStorage.getItem('digitrestau_supabase_key');

// Logique de sélection
const finalUrl = (envUrl && envUrl !== 'VOTRE_URL_SUPABASE_ICI') ? envUrl : (localUrl || (HARDCODED_URL !== 'VOTRE_URL_SUPABASE_ICI' ? HARDCODED_URL : null));
const finalKey = (envKey && envKey !== 'VOTRE_CLE_ANON_PUBLIC_ICI') ? envKey : (localKey || (HARDCODED_KEY !== 'VOTRE_CLE_ANON_PUBLIC_ICI' ? HARDCODED_KEY : null));

// Création du client ou null si aucune clé n'est trouvée
export const supabase = (finalUrl && finalKey) 
    ? createClient(finalUrl, finalKey) 
    : null;

// Petit log pour aider au débogage (visible dans la console)
if (!supabase) {
    console.warn("⚠️ Supabase non connecté. En attente des clés via le Dashboard ou le Code.");
} else {
    console.log("✅ Supabase connecté avec succès.");
}
