
import React, { useMemo, useState } from 'react';
import { Order, Dish } from './data';
import { supabase } from './supabaseClient';
import DishIcon from './icons/DishIcon';
import UserIcon from './icons/UserIcon';
import PackageIcon from './icons/PackageIcon'; // Using as generic store/home icon for FAB
import { Page } from '../App';

interface AdminDashboardProps {
    orders: Order[];
    dishes: Dish[];
    setPage: (page: Page) => void;
}

const StatCard: React.FC<{ title: string, value: string, color: string, icon: React.ReactNode }> = ({ title, value, color, icon }) => (
    <div className="bg-white p-4 rounded-3xl shadow-sm flex items-center space-x-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0 ${color}`}>
            {icon}
        </div>
        <div>
            <p className="text-stone-400 text-[10px] font-bold uppercase tracking-wider mb-0.5">{title}</p>
            <p className="text-2xl font-bold text-stone-900 leading-none">{value}</p>
        </div>
    </div>
);

const AdminDashboardPage: React.FC<AdminDashboardProps> = ({ orders, dishes, setPage }) => {
  const [urlInput, setUrlInput] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [activeTab, setActiveTab] = useState('Tout');
  
  const stats = useMemo(() => {
      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];

      const validOrders = orders.filter(o => o.status !== 'Annulée');
      const revenueToday = validOrders
        .filter(o => o.date.startsWith(todayStr))
        .reduce((sum, o) => sum + o.total, 0);
      
      const ordersCount = orders.length;
      const waitingCount = orders.filter(o => o.status === 'Confirmée' || o.status === 'En préparation').length;
      const deliveredCount = orders.filter(o => o.status === 'Livrée').length;
      
      return {
          revenueToday,
          ordersCount,
          waitingCount,
          deliveredCount
      };
  }, [orders]);

  const isSupabaseConnected = supabase !== null;

  const handleSaveKeys = () => {
      if (urlInput && keyInput) {
          localStorage.setItem('digitrestau_supabase_url', urlInput);
          localStorage.setItem('digitrestau_supabase_key', keyInput);
          window.location.reload();
      } else {
          alert("Veuillez remplir les deux champs.");
      }
  };

  return (
    <div className="pb-24 min-h-screen bg-gray-50"> {/* Padding bottom for FAB space */}
      
      {/* Black Header Section */}
      <div className="bg-[#1a1a1a] px-6 pt-6 pb-16 rounded-b-[3rem] shadow-xl relative z-10">
          <div className="flex justify-between items-center mb-6">
            <div>
                <h1 className="text-4xl font-bold font-serif text-white mb-1">Back-Office</h1>
                <p className="text-stone-400 text-sm">Gérez DigitRestau en toute simplicité.</p>
            </div>
          </div>

          {/* Navigation Buttons - Scroller horizontal */}
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide relative z-50">
              <button 
                onClick={() => setPage('admin-dashboard')}
                className="flex-shrink-0 flex items-center space-x-2 bg-amber-600 text-white px-5 py-3 rounded-xl shadow-lg transform active:scale-95 transition-transform"
              >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                  <span className="font-bold">Tableau de Bord</span>
              </button>
              <button 
                onClick={() => setPage('admin-plats')}
                className="flex-shrink-0 flex items-center space-x-2 bg-stone-800 text-stone-300 px-5 py-3 rounded-xl border border-stone-700 hover:bg-stone-700 hover:text-white transition-colors active:bg-stone-600"
              >
                  <DishIcon className="w-5 h-5" />
                  <span className="font-bold">Carte & Plats</span>
              </button>
               <button 
                onClick={() => setPage('admin-compte')}
                className="flex-shrink-0 flex items-center space-x-2 bg-stone-800 text-stone-300 px-5 py-3 rounded-xl border border-stone-700 hover:bg-stone-700 hover:text-white transition-colors active:bg-stone-600"
              >
                  <UserIcon className="w-5 h-5" />
                  <span className="font-bold">Clients & Fidélité</span>
              </button>
          </div>
      </div>

      {/* Stats Grid - Overlapping the header slightly */}
      <div className="px-6 -mt-10 relative z-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* REVENUS */}
                <StatCard 
                    title="REVENUS" 
                    value={`${stats.revenueToday.toLocaleString('fr-FR')} F`} 
                    color="bg-green-500" 
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>} 
                />
                
                {/* COMMANDES */}
                <StatCard 
                    title="COMMANDES" 
                    value={stats.ordersCount.toString()} 
                    color="bg-blue-500" 
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>} 
                />

                {/* EN ATTENTE */}
                <StatCard 
                    title="EN ATTENTE" 
                    value={stats.waitingCount.toString()} 
                    color="bg-amber-500" 
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>} 
                />

                {/* LIVRÉES */}
                <StatCard 
                    title="LIVRÉES" 
                    value={stats.deliveredCount.toString()} 
                    color="bg-stone-500" 
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>} 
                />
          </div>
      </div>

      {/* Connection Error Handler (Keep existing functionality but styled) */}
      {!isSupabaseConnected && (
         <div className="mx-6 mt-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-xl shadow-sm relative z-20">
             <h3 className="text-red-700 font-bold flex items-center gap-2">
                 ⚠️ Connexion Requise
             </h3>
             <p className="text-red-600 text-sm mb-3">
                 Entrez vos clés Supabase pour synchroniser les données.
             </p>
             <div className="space-y-2">
                <input 
                    type="text" 
                    value={urlInput} 
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="Project URL"
                    className="w-full border border-red-200 rounded px-3 py-2 text-sm bg-white"
                />
                <input 
                    type="password" 
                    value={keyInput} 
                    onChange={(e) => setKeyInput(e.target.value)}
                    placeholder="API Key"
                    className="w-full border border-red-200 rounded px-3 py-2 text-sm bg-white"
                />
                <button onClick={handleSaveKeys} className="w-full bg-red-600 text-white font-bold py-2 rounded hover:bg-red-700">Connecter</button>
             </div>
         </div>
      )}

      {/* Bottom Filter Pills */}
      <div className="px-6 mt-8 relative z-20">
          <div className="flex space-x-3 overflow-x-auto pb-2 scrollbar-hide">
              {['Tout', 'En Attente', 'En Cuisine', 'En Livraison'].map(filter => (
                  <button 
                    key={filter}
                    onClick={() => setActiveTab(filter)}
                    className={`px-6 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
                        activeTab === filter 
                        ? 'bg-stone-800 text-white' 
                        : 'bg-white text-stone-600 border border-stone-200 hover:bg-gray-100'
                    }`}
                  >
                      {filter}
                  </button>
              ))}
          </div>
          <p className="text-center text-stone-400 italic text-sm mt-8">Aucune commande trouvée.</p>
      </div>

      {/* Floating Action Button (FAB) */}
      <button className="fixed bottom-6 right-6 w-16 h-16 bg-amber-600 rounded-full shadow-2xl flex items-center justify-center text-white hover:bg-amber-500 transition-transform hover:scale-110 z-50 border-4 border-stone-100">
          <PackageIcon className="w-8 h-8" />
      </button>

    </div>
  );
};

export default AdminDashboardPage;
