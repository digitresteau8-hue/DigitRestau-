

import React, { useState, useEffect } from 'react';
import TrashIcon from './icons/TrashIcon';
import PencilIcon from './icons/PencilIcon';
import PlusIcon from './icons/PlusIcon';
import { Dish } from './data';

const resizeImage = (file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = reject;
        };
        reader.onerror = reject;
    });
};

interface AdminDishesPageProps {
    dishes: Dish[];
    onUpdateDishes: (dishes: Dish[], successMessage: string) => Promise<void>;
}

const emptyDishForm: Omit<Dish, 'id' | 'imageUrl'> & { imageUrl: string | null } = {
    name: '',
    category: 'Plat Africain',
    price: 0,
    description: '',
    imageUrl: null,
    isDailySpecial: false,
    tags: [],
    allergens: [],
};


const AdminDishesPage: React.FC<AdminDishesPageProps> = ({ dishes, onUpdateDishes }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentDish, setCurrentDish] = useState<Dish | null>(null);
    const [dishToDelete, setDishToDelete] = useState<Dish | null>(null);
    const [formData, setFormData] = useState(emptyDishForm);
    
    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'price' ? Number(value) : value }));
    };

    const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: checked }));
    };
    
    const handleTagChange = (tag: string) => {
        const currentTags = formData.tags || [];
        if (currentTags.includes(tag)) {
            setFormData(prev => ({ ...prev, tags: currentTags.filter(t => t !== tag) }));
        } else {
            setFormData(prev => ({ ...prev, tags: [...currentTags, tag] }));
        }
    };

    const handleAllergenChange = (allergen: string) => {
        const currentAllergens = formData.allergens || [];
        if (currentAllergens.includes(allergen)) {
            setFormData(prev => ({ ...prev, allergens: currentAllergens.filter(a => a !== allergen) }));
        } else {
            setFormData(prev => ({ ...prev, allergens: [...currentAllergens, allergen] }));
        }
    };

    const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            try {
                const resizedDataUrl = await resizeImage(file, 800, 800, 0.8);
                setFormData(prev => ({...prev, imageUrl: resizedDataUrl}));
            } catch (error) {
                console.error("Image resizing failed, using original:", error);
                const reader = new FileReader();
                reader.onloadend = () => {
                    setFormData(prev => ({...prev, imageUrl: reader.result as string}));
                };
                reader.readAsDataURL(file);
            }
        }
    };
    
    const openModal = (dish: Dish | null = null) => {
        setCurrentDish(dish);
        if (dish) {
            setFormData(dish);
        } else {
            setFormData(emptyDishForm);
        }
        setIsModalOpen(true);
    };
    
    const closeModal = () => {
        setIsModalOpen(false);
        setCurrentDish(null);
        setFormData(emptyDishForm);
    };

    const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        if (!formData.imageUrl) {
            alert("Veuillez sélectionner une image pour le plat.");
            return;
        }

        let updatedDishes;
        let successMessage = '';
        if (currentDish) { // Editing existing dish
            updatedDishes = dishes.map(d => d.id === currentDish.id ? { ...currentDish, ...formData } : d);
            successMessage = `Le plat "${formData.name}" a été mis à jour.`;
        } else { // Adding new dish
            const newDish: Dish = { ...formData, id: `d${Date.now()}`, imageUrl: formData.imageUrl };
            updatedDishes = [newDish, ...dishes];
            successMessage = `Le plat "${formData.name}" a été ajouté.`;
        }
        
        await onUpdateDishes(updatedDishes, successMessage);
        closeModal();
    };
    
    const openDeleteConfirm = (dish: Dish) => {
        setDishToDelete(dish);
    };
    
    const closeDeleteConfirm = () => {
        setDishToDelete(null);
    };

    const handleDelete = async () => {
        if (dishToDelete) {
            const updatedDishes = dishes.filter(d => d.id !== dishToDelete.id);
            await onUpdateDishes(updatedDishes, `Le plat "${dishToDelete.name}" a été supprimée.`);
            closeDeleteConfirm();
        }
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-serif text-stone-900">Gestion des Plats</h1>
                <button 
                    onClick={() => openModal()}
                    className="flex items-center space-x-2 bg-amber-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-amber-800 transition duration-300 shadow"
                >
                    <PlusIcon className="w-5 h-5" />
                    <span>Ajouter un plat</span>
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
                {!dishes ? (
                    <p className="text-center text-stone-500">Chargement des plats...</p>
                ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b">
                                <th className="p-4">Image</th>
                                <th className="p-4">Nom</th>
                                <th className="p-4">Catégorie</th>
                                <th className="p-4">Prix</th>
                                <th className="p-4">Tags</th>
                                <th className="p-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dishes.map(dish => (
                                <tr key={dish.id} className="border-b hover:bg-stone-50">
                                    <td className="p-4"><img src={dish.imageUrl} alt={dish.name} className="w-16 h-16 object-cover rounded-md" /></td>
                                    <td className="p-4 font-semibold">{dish.name}</td>
                                    <td className="p-4">{dish.category}</td>
                                    <td className="p-4">{dish.price.toLocaleString('fr-FR')} CFA</td>
                                    <td className="p-4">
                                        <div className="flex flex-wrap gap-1">
                                            {dish.isDailySpecial && <span className="px-2 py-0.5 text-xs bg-amber-100 text-amber-700 rounded-full">Jour</span>}
                                            {dish.tags?.map(t => <span key={t} className="px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded-full">{t}</span>)}
                                        </div>
                                    </td>
                                    <td className="p-4">
                                        <div className="flex space-x-2">
                                            <button onClick={() => openModal(dish)} className="p-2 text-stone-500 hover:text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-5 h-5"/></button>
                                            <button onClick={() => openDeleteConfirm(dish)} className="p-2 text-stone-500 hover:text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                )}
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
                        <h3 className="text-lg font-bold text-stone-900 mb-4">{currentDish ? 'Modifier le plat' : 'Ajouter un nouveau plat'}</h3>
                        <form onSubmit={handleFormSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-stone-700">Nom du plat</label>
                                <input type="text" name="name" id="name" value={formData.name} onChange={handleFormChange} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-600 focus:border-amber-600"/>
                            </div>
                             <div>
                                <label htmlFor="category" className="block text-sm font-medium text-stone-700">Catégorie</label>
                                <input list="category-suggestions" type="text" name="category" id="category" value={formData.category} onChange={handleFormChange} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-600 focus:border-amber-600"/>
                                <datalist id="category-suggestions">
                                    <option value="Plat Africain" />
                                    <option value="Plat Européen" />
                                    <option value="Boisson" />
                                    <option value="Dessert" />
                                </datalist>
                            </div>
                            <div>
                                <label htmlFor="price" className="block text-sm font-medium text-stone-700">Prix (CFA)</label>
                                <input type="number" name="price" id="price" value={formData.price || ''} onChange={handleFormChange} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-600 focus:border-amber-600"/>
                            </div>
                            <div>
                                <label htmlFor="description" className="block text-sm font-medium text-stone-700">Description</label>
                                <textarea name="description" id="description" value={formData.description} onChange={handleFormChange} required rows={3} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-600 focus:border-amber-600"></textarea>
                            </div>
                            
                            {/* Tags & Options */}
                            <div className="bg-gray-50 p-4 rounded-md space-y-3 border border-gray-200">
                                <p className="text-sm font-bold text-gray-700">Options & Tags</p>
                                
                                <div className="flex items-center">
                                    <input type="checkbox" name="isDailySpecial" id="isDailySpecial" checked={formData.isDailySpecial || false} onChange={handleCheckboxChange} className="h-4 w-4 text-amber-600 rounded border-gray-300"/>
                                    <label htmlFor="isDailySpecial" className="ml-2 text-sm text-gray-700 font-bold text-amber-700">Plat du Jour</label>
                                </div>

                                <div className="flex flex-wrap gap-3">
                                    {['Épicé', 'Végétarien'].map(tag => (
                                        <div key={tag} className="flex items-center">
                                            <input 
                                                type="checkbox" 
                                                id={`tag-${tag}`} 
                                                checked={formData.tags?.includes(tag) || false} 
                                                onChange={() => handleTagChange(tag)} 
                                                className="h-4 w-4 text-amber-600 rounded border-gray-300"
                                            />
                                            <label htmlFor={`tag-${tag}`} className="ml-2 text-sm text-gray-700">{tag}</label>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Allergènes */}
                            <div className="bg-gray-50 p-4 rounded-md space-y-3 border border-gray-200">
                                <p className="text-sm font-bold text-gray-700">Allergènes (à cocher si présents)</p>
                                <div className="flex flex-wrap gap-3">
                                    {['Arachide', 'Gluten', 'Lactose', 'Poisson', 'Crustacés', 'Oeuf'].map(allergen => (
                                        <div key={allergen} className="flex items-center">
                                            <input 
                                                type="checkbox" 
                                                id={`allergen-${allergen}`} 
                                                checked={formData.allergens?.includes(allergen) || false} 
                                                onChange={() => handleAllergenChange(allergen)} 
                                                className="h-4 w-4 text-red-600 rounded border-gray-300"
                                            />
                                            <label htmlFor={`allergen-${allergen}`} className="ml-2 text-sm text-gray-700">{allergen}</label>
                                        </div>
                                    ))}
                                </div>
                            </div>

                             <div>
                                <label className="block text-sm font-medium text-stone-700">Image du plat</label>
                                {formData.imageUrl && <img src={formData.imageUrl} alt="Aperçu du plat" className="mt-2 w-32 h-32 object-cover rounded-md" />}
                                <div className="mt-2">
                                    <input type="file" id="imageUpload" accept="image/*" onChange={handleImageChange} className="hidden" />
                                    <label htmlFor="imageUpload" className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-stone-700 hover:bg-stone-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-600">
                                        Choisir une image
                                    </label>
                                </div>
                            </div>
                            <div className="mt-6 flex justify-end space-x-3">
                                <button type="button" onClick={closeModal} className="px-4 py-2 bg-stone-200 text-stone-800 rounded-md hover:bg-stone-300 transition">Annuler</button>
                                <button type="submit" className="px-4 py-2 bg-amber-700 text-white rounded-md hover:bg-amber-800 transition">{currentDish ? 'Sauvegarder' : 'Ajouter'}</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {dishToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                        <h3 className="text-lg font-bold text-stone-900">Confirmer la Suppression</h3>
                        <p className="mt-2 text-sm text-stone-600">
                            Êtes-vous sûr de vouloir supprimer le plat <strong>{dishToDelete.name}</strong> ? Cette action est irréversible.
                        </p>
                        <div className="mt-6 flex justify-end space-x-3">
                            <button onClick={closeDeleteConfirm} className="px-4 py-2 bg-stone-200 text-stone-800 rounded-md hover:bg-stone-300 transition">Annuler</button>
                            <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition">Supprimer</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminDishesPage;