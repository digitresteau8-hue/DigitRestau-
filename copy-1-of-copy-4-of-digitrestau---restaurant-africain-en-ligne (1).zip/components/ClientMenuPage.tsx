

import React, { useState, useMemo } from 'react';
import { Dish, User, Review } from './data';
import MenuIcon from './icons/MenuIcon';
import DishCard from './DishCard';
import DishDetailModal from './DishDetailModal';

interface ClientMenuPageProps {
    dishes: Dish[];
    addToCart: (dish: Dish, quantity: number, instructions: string) => void;
    currentUser: User | null;
    addReview: (dishId: string, review: Omit<Review, 'id'>) => void;
    editReview: (dishId: string, review: Review) => void;
    deleteReview: (dishId: string, reviewId: string) => void;
}

const ClientMenuPage: React.FC<ClientMenuPageProps> = ({ dishes, addToCart, currentUser, addReview, editReview, deleteReview }) => {
    const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [activeCategory, setActiveCategory] = useState('Tout');
    
    // État pour les filtres intelligents
    const [activeFilters, setActiveFilters] = useState<Set<string>>(new Set());
    const [showAllergens, setShowAllergens] = useState(false);
    const [excludeAllergens, setExcludeAllergens] = useState<Set<string>>(new Set());

    const toggleFilter = (filter: string) => {
        const newFilters = new Set(activeFilters);
        if (newFilters.has(filter)) {
            newFilters.delete(filter);
        } else {
            newFilters.add(filter);
        }
        setActiveFilters(newFilters);
    };
    
    const toggleAllergen = (allergen: string) => {
        const newAllergens = new Set(excludeAllergens);
        if (newAllergens.has(allergen)) {
            newAllergens.delete(allergen);
        } else {
            newAllergens.add(allergen);
        }
        setExcludeAllergens(newAllergens);
    };

    const filteredDishes = useMemo(() => {
        let result = dishes;

        // 1. Recherche Texte
        if (searchTerm) {
            const lowerTerm = searchTerm.toLowerCase();
            result = result.filter(d => 
                d.name.toLowerCase().includes(lowerTerm) || 
                d.description.toLowerCase().includes(lowerTerm) ||
                d.category.toLowerCase().includes(lowerTerm)
            );
        }

        // 2. Filtres Intelligents (ET logique)
        if (activeFilters.size > 0) {
            if (activeFilters.has('Plat du jour')) {
                result = result.filter(d => d.isDailySpecial);
            }
            if (activeFilters.has('Petits Prix')) {
                result = result.filter(d => d.price < 3000);
            }
            if (activeFilters.has('Épicé')) {
                result = result.filter(d => d.tags?.includes('Épicé'));
            }
            if (activeFilters.has('Végétarien')) {
                result = result.filter(d => d.tags?.includes('Végétarien'));
            }
        }
        
        // 3. Exclusion Allergènes
        if (excludeAllergens.size > 0) {
            result = result.filter(d => {
                if (!d.allergens) return true;
                return !d.allergens.some(allergen => excludeAllergens.has(allergen));
            });
        }

        return result;
    }, [dishes, searchTerm, activeFilters, excludeAllergens]);

    const menuByCategory = useMemo(() => {
        return filteredDishes.reduce((acc, dish) => {
            const category = dish.category || 'Autres';
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(dish);
            return acc;
        }, {} as Record<string, Dish[]>);
    }, [filteredDishes]);
    

    const categories = Object.keys(menuByCategory).sort((a, b) => {
        const order = ['Plat Africain', 'Plat Européen', 'Boisson', 'Dessert'];
        const idxA = order.indexOf(a);
        const idxB = order.indexOf(b);
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        if (idxA !== -1) return -1;
        if (idxB !== -1) return 1;
        return a.localeCompare(b);
    });

    const handleDishClick = (dish: Dish) => {
        setSelectedDish(dish);
    };

    const closeModal = () => {
        setSelectedDish(null);
    };
    
    const scrollToCategory = (category: string) => {
        setActiveCategory(category);
        const element = document.getElementById(category.toLowerCase().replace(/\s/g, '-'));
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };
    
    const FilterChip = ({ label, icon, isActive, onClick }: { label: string, icon: string, isActive: boolean, onClick: () => void }) => (
         <button
            onClick={onClick}
            className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all duration-300 border flex items-center gap-2 ${
                isActive 
                ? 'bg-cyan-600 text-white border-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.4)]' 
                : 'bg-slate-900/80 text-slate-400 border-white/10 hover:border-cyan-500/30 hover:text-white'
            }`}
        >
            <span>{icon}</span>
            {label}
        </button>
    );

    return (
        <section id="menu" className="pt-28 pb-10 min-h-screen">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <div className="inline-block bg-slate-900/80 p-4 rounded-full mb-4 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                        <MenuIcon className="w-10 h-10 text-cyan-400" />
                    </div>
                    <h2 className="text-4xl font-bold font-serif text-white mb-4 neon-text">La Carte</h2>
                    <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                        Fusion gastronomique et excellence culinaire.
                    </p>
                </div>

                 {/* Barre de Contrôles (Sticky) */}
                 <div className="sticky top-20 z-30 bg-slate-950/95 backdrop-blur-xl py-4 -mx-6 px-6 mb-12 border-b border-white/5 shadow-2xl">
                     <div className="container mx-auto flex flex-col gap-4">
                         {/* Recherche */}
                        <div className="relative max-w-md mx-auto w-full group">
                            <input
                                type="text"
                                placeholder="Rechercher un plat..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-white/10 rounded-full text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 shadow-inner transition-all"
                            />
                            <svg className="w-6 h-6 text-cyan-500 absolute left-4 top-1/2 transform -translate-y-1/2 group-hover:text-cyan-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </div>

                        {/* Catégories (Horizontal Scroll) */}
                        <div className="flex space-x-3 overflow-x-auto pb-1 scrollbar-hide justify-start md:justify-center">
                             <button
                                onClick={() => { setActiveCategory('Tout'); window.scrollTo({top:0, behavior:'smooth'})}}
                                className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-bold transition-all duration-300 border ${
                                    activeCategory === 'Tout' 
                                    ? 'bg-cyan-600 text-white border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.5)]' 
                                    : 'bg-slate-900 text-slate-400 border-white/10 hover:border-cyan-500/50 hover:text-white'
                                }`}
                             >
                                Tout voir
                            </button>
                            {categories.map(category => (
                                <button
                                    key={category}
                                    onClick={() => scrollToCategory(category)}
                                    className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-bold transition-all duration-300 border ${
                                        activeCategory === category 
                                        ? 'bg-cyan-600 text-white border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.5)]' 
                                        : 'bg-slate-900 text-slate-400 border-white/10 hover:border-cyan-500/50 hover:text-white'
                                    }`}
                                >
                                    {category}
                                </button>
                            ))}
                        </div>
                        
                        {/* Filtres Intelligents (Smart Filters) */}
                        <div className="flex flex-wrap gap-3 justify-center pt-2 border-t border-white/5">
                            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider self-center mr-2">Filtres :</span>
                            <FilterChip 
                                label="Plat du jour" 
                                icon="⭐" 
                                isActive={activeFilters.has('Plat du jour')} 
                                onClick={() => toggleFilter('Plat du jour')} 
                            />
                            <FilterChip 
                                label="Épicé" 
                                icon="🌶️" 
                                isActive={activeFilters.has('Épicé')} 
                                onClick={() => toggleFilter('Épicé')} 
                            />
                            <FilterChip 
                                label="Végétarien" 
                                icon="🌿" 
                                isActive={activeFilters.has('Végétarien')} 
                                onClick={() => toggleFilter('Végétarien')} 
                            />
                            <FilterChip 
                                label="Petits Prix" 
                                icon="💰" 
                                isActive={activeFilters.has('Petits Prix')} 
                                onClick={() => toggleFilter('Petits Prix')} 
                            />
                             <button
                                onClick={() => setShowAllergens(!showAllergens)}
                                className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all duration-300 border flex items-center gap-2 ${
                                    showAllergens || excludeAllergens.size > 0
                                    ? 'bg-amber-900/30 text-amber-400 border-amber-500/50' 
                                    : 'bg-slate-900/80 text-slate-400 border-white/10 hover:border-amber-500/30 hover:text-white'
                                }`}
                            >
                                <span>⚠️</span> Allergies {excludeAllergens.size > 0 && `(${excludeAllergens.size})`}
                            </button>
                        </div>

                        {/* Panneau Allergènes */}
                        {showAllergens && (
                             <div className="bg-slate-900/90 p-4 rounded-xl border border-amber-500/20 animate-fade-in">
                                 <p className="text-xs text-slate-400 mb-2 uppercase font-bold">Exclure les plats contenant :</p>
                                 <div className="flex flex-wrap gap-2">
                                     {['Arachide', 'Gluten', 'Lactose', 'Poisson', 'Crustacés', 'Oeuf'].map(allergen => (
                                         <button
                                            key={allergen}
                                            onClick={() => toggleAllergen(allergen)}
                                            className={`px-3 py-1 rounded text-xs transition-colors ${
                                                excludeAllergens.has(allergen) 
                                                ? 'bg-red-500/20 text-red-400 border border-red-500/50 line-through decoration-red-400' 
                                                : 'bg-slate-800 text-slate-300 border border-white/5 hover:bg-slate-700'
                                            }`}
                                         >
                                             {allergen}
                                         </button>
                                     ))}
                                 </div>
                             </div>
                        )}
                     </div>
                 </div>

                <div className="space-y-20">
                    {categories.map((category) => (
                        <div key={category} id={category.toLowerCase().replace(/\s/g, '-')} className="scroll-mt-64">
                            <div className="flex items-center gap-4 mb-8">
                                <div className="h-px flex-1 bg-gradient-to-r from-transparent to-cyan-500/50"></div>
                                <h3 className="text-3xl font-bold font-serif text-cyan-400 neon-text text-center">
                                    {category}
                                </h3>
                                <div className="h-px flex-1 bg-gradient-to-l from-transparent to-cyan-500/50"></div>
                            </div>
                            
                            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                                {menuByCategory[category].map((dish) => (
                                    <DishCard 
                                        key={dish.id} 
                                        dish={dish} 
                                        onAddToCart={addToCart}
                                        onDishClick={handleDishClick}
                                    />
                                ))}
                            </div>
                        </div>
                    ))}

                    {categories.length === 0 && (
                        <div className="text-center text-slate-500 py-12 bg-slate-900 rounded-xl border border-white/5">
                            <p className="text-xl">Aucun plat ne correspond à vos filtres.</p>
                            <button 
                                onClick={() => { setSearchTerm(''); setActiveFilters(new Set()); setExcludeAllergens(new Set()); }} 
                                className="mt-4 text-cyan-500 hover:underline"
                            >
                                Réinitialiser les filtres
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {selectedDish && (
                <DishDetailModal 
                    dish={selectedDish} 
                    onClose={closeModal} 
                    onAddToCart={addToCart} 
                    currentUser={currentUser}
                    onAddReview={addReview}
                    onEditReview={editReview}
                    onDeleteReview={deleteReview}
                />
            )}
            
            <style>{`
                .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                }
                .scrollbar-hide {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(-5px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.2s ease-out forwards;
                }
            `}</style>
        </section>
    );
};

export default ClientMenuPage;
