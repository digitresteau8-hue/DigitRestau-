
import React, { useRef, useState } from 'react';
import UserIcon from './icons/UserIcon';
import { User } from './data';
import CameraIcon from './icons/CameraIcon';
import { authUpdateUser } from './db';

interface AdminAccountPageProps {
    currentUser?: User | null;
}

// Fonction utilitaire pour redimensionner les images (Base64)
const resizeImage = (file: File, maxWidth: number, maxHeight: number): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', 0.7));
            };
            img.onerror = reject;
        };
        reader.onerror = reject;
    });
};

const AdminAccountPage: React.FC<AdminAccountPageProps> = ({ currentUser }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setIsUploading(true);
      try {
          const base64Image = await resizeImage(file, 200, 200);
          await authUpdateUser({ avatarUrl: base64Image });
          alert("Photo d'administrateur mise à jour !");
          window.location.reload(); 
      } catch (err) {
          console.error("Upload failed", err);
          alert("Erreur lors de la mise à jour de la photo.");
      } finally {
          setIsUploading(false);
      }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold font-serif text-white mb-6 neon-text">Compte Administrateur</h1>
      <div className="bg-slate-900 border border-white/10 p-8 rounded-xl shadow-lg max-w-2xl">
        
        <div className="flex items-center space-x-6 mb-8">
            {/* Avatar avec Upload */}
            <div className="relative group">
                 <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-amber-600 bg-slate-800 flex items-center justify-center shadow-[0_0_15px_rgba(217,119,6,0.4)]">
                    {currentUser?.avatarUrl ? (
                        <img src={currentUser.avatarUrl} alt="Admin Avatar" className="w-full h-full object-cover" />
                    ) : (
                        <UserIcon className="w-12 h-12 text-amber-600" />
                    )}
                 </div>
                 <button 
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="absolute bottom-0 right-0 bg-white hover:bg-amber-500 text-amber-700 hover:text-white p-2 rounded-full shadow-lg border border-gray-200 transition-all"
                    title="Changer la photo"
                 >
                    <CameraIcon className={`w-5 h-5 ${isUploading ? 'animate-spin' : ''}`} />
                 </button>
                 <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleAvatarChange}
                 />
            </div>

            <div>
                <h2 className="text-2xl font-bold text-white">{currentUser?.name || 'Admin'}</h2>
                <p className="text-slate-400">{currentUser?.email || 'admin@digitrestau.com'}</p>
                <span className="inline-block mt-2 px-3 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/50 rounded-full text-xs font-bold uppercase">
                    Super Admin
                </span>
            </div>
        </div>

        <div className="bg-slate-950 border border-white/5 rounded-lg p-6">
             <h3 className="text-lg font-bold text-white mb-4">Sécurité & Paramètres</h3>
             <p className="text-slate-400 text-sm mb-4">
                Modifiez votre mot de passe ou mettez à jour vos informations de contact. Pour des raisons de sécurité, ces modifications nécessitent une re-connexion.
             </p>
             <div className="grid gap-4">
                 <div className="flex flex-col">
                     <label className="text-xs text-slate-500 uppercase font-bold mb-1">Identifiant Staff</label>
                     <input disabled value={currentUser?.id || 'ADMIN-001'} className="bg-slate-900 border border-slate-700 text-slate-400 p-2 rounded" />
                 </div>
                 <button className="bg-slate-800 hover:bg-slate-700 text-white py-2 px-4 rounded border border-white/10 transition-colors">
                     Modifier le Mot de Passe (Bientôt disponible)
                 </button>
             </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAccountPage;
