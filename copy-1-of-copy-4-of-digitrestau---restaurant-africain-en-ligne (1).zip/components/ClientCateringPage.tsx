



import React from 'react';
import CateringIcon from './icons/CateringIcon';

const ClientCateringPage: React.FC = () => {
  return (
    <section id="catering" className="pt-28 pb-10 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <div className="inline-block bg-stone-900/80 p-4 rounded-full mb-4 border border-amber-500/30">
                <CateringIcon className="w-10 h-10 text-amber-500" />
            </div>
            <h2 className="text-4xl font-bold font-serif text-white mb-4">Service Traiteur</h2>
            <p className="text-lg text-stone-400 max-w-2xl mx-auto">
                Sublimons vos événements spéciaux ensemble.
            </p>
        </div>
        <div className="text-center text-stone-400 bg-stone-900/80 backdrop-blur p-8 rounded-xl border border-white/5 max-w-2xl mx-auto">
            <p>Un formulaire de contact détaillé pour les demandes de service traiteur (mariage, baptême, anniversaire, etc.) sera disponible ici.</p>
            <p className="mt-4 text-amber-500 italic">Cette fonctionnalité est en cours de développement.</p>
        </div>
      </div>
    </section>
  );
};

export default ClientCateringPage;