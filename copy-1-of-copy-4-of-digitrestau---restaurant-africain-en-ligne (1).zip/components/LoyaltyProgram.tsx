
import React from 'react';
import GiftIcon from './icons/GiftIcon';

const LoyaltyProgram: React.FC = () => {
  return (
    <section id="loyalty" className="py-20 bg-stone-900 text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-10">
          <div className="md:w-1/3 text-center">
            <GiftIcon className="w-24 h-24 text-amber-500 mx-auto mb-4" />
          </div>
          <div className="md:w-2/3 text-center md:text-left">
            <h2 className="text-4xl font-bold font-serif text-stone-200 mb-4">Votre Fidélité Récompensée</h2>
            <p className="text-xl text-stone-300 leading-relaxed">
              Nous aimons nos clients fidèles ! Profitez de réductions de <strong>5% à 10%</strong> sur vos commandes, échangeables contre un jus rafraîchissant ou un plat de votre choix. Plus vous commandez, plus vous êtes récompensé.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoyaltyProgram;
