
import React from 'react';
import { Page } from '../App';
import DeliveryIcon from './icons/DeliveryIcon';
import CateringIcon from './icons/CateringIcon';
import BoxIcon from './icons/BoxIcon';
import MenuHighlight from './MenuHighlight';
import LoyaltyProgram from './LoyaltyProgram';
import Footer from './Footer';


const ServiceCard: React.FC<{ icon: React.ReactNode; title: string; description: string; }> = ({ icon, title, description }) => (
  <div className="bg-slate-900/50 backdrop-blur-md p-8 rounded-xl shadow-lg hover:shadow-cyan-500/20 transition-all duration-300 transform hover:-translate-y-2 flex flex-col items-center text-center border border-white/5 hover:border-cyan-500/30 group">
    <div className="bg-slate-800 p-4 rounded-full mb-6 text-cyan-400 group-hover:text-cyan-300 group-hover:shadow-[0_0_15px_rgba(34,211,238,0.4)] transition-all">{icon}</div>
    <h3 className="text-2xl font-bold font-serif text-white mb-3 group-hover:text-cyan-400 transition-colors">{title}</h3>
    <p className="text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">{description}</p>
  </div>
);

interface ClientHomePageProps {
  setPage: (page: Page) => void;
}

const ClientHomePage: React.FC<ClientHomePageProps> = ({ setPage }) => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center text-white text-center bg-cover bg-center" style={{ backgroundImage: "url('https://i.ibb.co/3m4x0g0/thieboudienne.jpg')" }}>
        {/* Overlay Cyber */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-900/80 to-slate-950"></div>
        
        <div className="relative z-10 p-6 max-w-5xl flex flex-col items-center animate-fade-in-up">
          <img src="https://i.ibb.co/WWHPStfL/1759863774896.png" alt="DigitRestau Logo" className="w-48 h-auto mb-8 drop-shadow-[0_0_25px_rgba(6,182,212,0.6)] animate-pulse-slow" />
          <h1 className="text-5xl md:text-7xl font-bold font-serif leading-tight tracking-wide mb-6 drop-shadow-lg text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-white to-blue-300 neon-text">
            L'Excellence Culinaire
          </h1>
          <p className="text-xl md:text-3xl font-light mb-10 drop-shadow-md text-cyan-100 tracking-[0.2em] uppercase border-b border-cyan-500/30 pb-2">
            Le Goût Livré Chez Vous
          </p>
          <button
            onClick={() => setPage('menu')}
            className="bg-gradient-to-r from-cyan-600 to-blue-600 backdrop-blur text-white font-bold py-4 px-12 text-lg rounded-full hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 ease-in-out transform hover:scale-105 hover:-translate-y-1 hover:rotate-1 shadow-[0_0_30px_rgba(6,182,212,0.4)] border border-cyan-400/50"
          >
            Découvrir le Menu
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-slate-950 relative overflow-hidden">
        {/* Decorative Blobs */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-600/10 rounded-full blur-[100px]"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2 relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
              <img src="https://i.ibb.co/JqPz3sN/yassa-poulet.jpg" alt="Cuisine Africaine" className="relative rounded-lg shadow-2xl w-full h-96 object-cover border border-white/10"/>
            </div>
            <div className="md:w-1/2">
              <h2 className="text-4xl font-bold font-serif text-white mb-6 border-l-4 border-cyan-500 pl-4 neon-text">Notre Passion</h2>
              <p className="text-lg text-slate-300 mb-4 leading-relaxed">Chez DigitRestau, la tradition rencontre l'innovation. Nous fusionnons les saveurs authentiques de l'Afrique avec une expérience digitale de classe mondiale.</p>
              <p className="text-lg text-slate-300 leading-relaxed">Ingrédients premium, préparation méticuleuse et technologie de pointe pour une livraison ultra-rapide.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-slate-900 border-t border-white/5">
        <div className="container mx-auto px-6">
            <div className="text-center mb-16">
                <h2 className="text-4xl font-bold font-serif text-white mb-4 neon-text">Services Premium</h2>
                <p className="text-lg text-slate-400 max-w-2xl mx-auto">L'expérience restaurant réinventée.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-10">
              <ServiceCard
                icon={<DeliveryIcon className="w-10 h-10" />}
                title="Livraison Éclair"
                description="Suivi GPS en temps réel. Vos plats arrivent chauds grâce à nos sacs isothermes High-Tech."
              />
              <ServiceCard
                icon={<CateringIcon className="w-10 h-10" />}
                title="Traiteur VIP"
                description="Pour vos événements prestigieux. Un service sur-mesure digne des plus grands palaces."
              />
              <ServiceCard
                icon={<BoxIcon className="w-10 h-10" />}
                title="Boxs Signature"
                description="Emportez l'essence de notre cuisine. Des sauces mijotées prêtes à déguster."
              />
            </div>
        </div>
      </section>

      {/* Menu Highlight Section */}
      <MenuHighlight setPage={setPage} />

      {/* Loyalty Program Section */}
      <LoyaltyProgram />

      {/* Footer */}
      <Footer />
       <style>{`
        @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
            animation: fade-in-up 0.8s ease-out forwards;
        }
        .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
      `}</style>
    </>
  );
};

export default ClientHomePage;
