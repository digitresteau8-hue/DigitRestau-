

export interface Review {
    id: string;
    userId: string;
    userName: string;
    rating: number; // 1 to 5
    comment: string;
    date: string;
}

export interface User {
    id: string;
    name: string;
    phone: string;
    email?: string;
    points?: number;
    avatarUrl?: string;
    isAdmin?: boolean; // Nouveau champ pour le rôle Admin
}

export interface LoyaltyReward {
    id: string;
    name: string;
    cost: number;
    description: string;
    type: 'discount' | 'item';
}

export const rewards: LoyaltyReward[] = [
    { id: 'rw1', name: 'Jus Offert', cost: 50, description: 'Un jus de Bissap ou Gingembre frais.', type: 'item' },
    { id: 'rw2', name: 'Réduction 5%', cost: 100, description: '5% de remise sur votre prochaine commande.', type: 'discount' },
    { id: 'rw3', name: 'Plat Offert', cost: 500, description: 'Un plat au choix (max 3000 F).', type: 'item' },
    { id: 'rw4', name: 'Réduction 10%', cost: 800, description: '10% de remise sur votre prochaine commande.', type: 'discount' },
];

export interface Dish {
    id: string;
    name: string;
    category: string;
    price: number;
    imageUrl: string;
    description: string;
    reviews?: Review[];
    isDailySpecial?: boolean;
    tags?: string[]; // Ex: ['Épicé', 'Végétarien']
    allergens?: string[]; // Ex: ['Arachide', 'Gluten']
}

export interface CartItem extends Dish {
    quantity: number;
    specialInstructions?: string;
}


export interface Box {
    id: string;
    name: string;
    price: number;
    description: string;
}

export type OrderStatus = 'Confirmée' | 'En préparation' | 'Prête' | 'En cours de livraison' | 'Livrée' | 'Annulée';

export interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  specialInstructions?: string;
}

export interface Order {
  id: string;
  date: string;
  customerName: string;
  customerId: string;
  customerPhone: string;
  deliveryAddress: string;
  items: OrderItem[];
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  paymentMethod: string;
  deliveryCoords?: { lat: number; lng: number; };
}

export interface Settings {
    paymentMethods: string[];
    deliveryFees: {
        centreVille: number;
        peripherie: number;
        nightCentreVille: number; // Tarif nuit Centre
        nightPeripherie: number;  // Tarif nuit Périphérie
    };
    openingHours: {
        weekdays: string;
        sunday: string;
    };
    deliveryZones: {
        centreVille: string[];
        peripherie: string[];
    };
}


const demoReviews: Review[] = [
    { id: 'r1', userId: 'u1', userName: 'Aïcha T.', rating: 5, comment: 'Le meilleur Thieboudienne de Niamey, sans hésiter ! Frais et savoureux.', date: '2023-10-25' },
    { id: 'r2', userId: 'u2', userName: 'Moussa D.', rating: 4, comment: 'Très bon, mais j\'aurais aimé un peu plus de légumes.', date: '2023-10-24' },
];


export const initialDishes: Dish[] = [
    // Plats Africains (15)
    { id: 'd01', name: 'Thieboudienne Poisson', category: 'Plat Africain', price: 4500, imageUrl: 'https://i.ibb.co/3m4x0g0/thieboudienne.jpg', description: 'Le plat national sénégalais, riz au poisson et légumes frais.', reviews: demoReviews, isDailySpecial: true, tags: [], allergens: ['Poisson'] },
    { id: 'd02', name: 'Yassa Poulet', category: 'Plat Africain', price: 3500, imageUrl: 'https://i.ibb.co/JqPz3sN/yassa-poulet.jpg', description: 'Poulet mariné au citron et oignons, grillé à la perfection.', tags: ['Épicé'], allergens: [] },
    { id: 'd03', name: 'Mafe', category: 'Plat Africain', price: 4000, imageUrl: 'https://i.ibb.co/rpxQb9r/mafe.jpg', description: 'Viande tendre mijotée dans une sauce arachide riche et savoureuse.', tags: [], allergens: ['Arachide'] },
    { id: 'd04', name: 'Poisson Braisé', category: 'Plat Africain', price: 5000, imageUrl: 'https://i.ibb.co/8D9GZzY/poisson-braise.jpg', description: 'Poisson frais entier, assaisonné et grillé, servi avec alloco.', tags: ['Épicé'], allergens: ['Poisson'] },
    { id: 'd05', name: 'Dibi (Mouton grillé)', category: 'Plat Africain', price: 6000, imageUrl: 'https://i.ibb.co/Qn1kQ1d/dibi.jpg', description: 'Tendres morceaux de mouton marinés et grillés, servis avec des oignons.', tags: ['Épicé'], allergens: [] },
    { id: 'd06', name: 'Foutou Banane & Sauce Graine', category: 'Plat Africain', price: 4000, imageUrl: 'https://i.ibb.co/6P0h3jJ/foutou.jpg', description: 'Purée de banane plantain servie avec une délicieuse sauce aux noix de palme.', tags: [], allergens: [] },
    { id: 'd07', name: 'Kedjenou de Poulet', category: 'Plat Africain', price: 4500, imageUrl: 'https://i.ibb.co/Gvx0v0m/kedjenou.jpg', description: 'Poulet mijoté aux légumes et épices dans une sauce savoureuse.', tags: ['Épicé'], allergens: [] },
    { id: 'd08', name: 'Attiéké Poisson', category: 'Plat Africain', price: 4500, imageUrl: 'https://i.ibb.co/yQJ4xQ8/attieke.jpg', description: 'Semoule de manioc accompagnée de poisson frit ou braisé et de crudités.', tags: [], allergens: ['Poisson'] },
    { id: 'd09', name: 'Ndolé', category: 'Plat Africain', price: 5500, imageUrl: 'https://i.ibb.co/yq4Yf7m/ndole.jpg', description: 'Plat camerounais à base de feuilles amères, arachides et viande ou crevettes.', tags: [], allergens: ['Arachide', 'Crevettes'] },
    { id: 'd10', name: 'Saka Saka', category: 'Plat Africain', price: 4000, imageUrl: 'https://i.ibb.co/L51D4z5/saka-saka.jpg', description: 'Feuilles de manioc pilées et mijotées avec de l\'huile de palme et du poisson fumé.', tags: ['Végétarien'], allergens: ['Poisson'] },
    { id: 'd11', name: 'Eru', category: 'Plat Africain', price: 5000, imageUrl: 'https://i.ibb.co/Zc2yT7n/eru.jpg', description: 'Spécialité camerounaise à base de Gnetum africanum, huile de palme et viande.', tags: [], allergens: [] },
    { id: 'd12', name: 'Soupe Kandia (Gombo)', category: 'Plat Africain', price: 3500, imageUrl: 'https://i.ibb.co/Rz8s0hX/gombo.jpg', description: 'Soupe gluante à base de gombo, viande et fruits de mer.', tags: [], allergens: ['Crustacés'] },
    { id: 'd13', name: 'Riz au Gras', category: 'Plat Africain', price: 3000, imageUrl: 'https://i.ibb.co/R7r1M0T/riz-gras.jpg', description: 'Riz cuit dans un bouillon de viande et de légumes riche en saveurs.', tags: [], allergens: [] },
    { id: 'd14', name: 'Alloco', category: 'Plat Africain', price: 1500, imageUrl: 'https://i.ibb.co/2ZkS2hX/alloco.jpg', description: 'Bananes plantain mûres frites, servies en accompagnement ou en plat.', tags: ['Végétarien'], allergens: [] },
    { id: 'd15', name: 'Brochettes de boeuf', category: 'Plat Africain', price: 2500, imageUrl: 'https://i.ibb.co/1K2TzpR/brochette.jpg', description: 'Cubes de boeuf marinés et grillés, un classique de la street food.', tags: [], allergens: [] },

    // Plats Européens (10)
    { id: 'd16', name: 'Pizza Margherita', category: 'Plat Européen', price: 5000, imageUrl: 'https://i.ibb.co/m98pG9g/pizza.jpg', description: 'La classique pizza italienne avec sauce tomate, mozzarella et basilic frais.', tags: ['Végétarien'], allergens: ['Gluten', 'Lactose'] },
    { id: 'd17', name: 'Spaghetti Bolognaise', category: 'Plat Européen', price: 4500, imageUrl: 'https://i.ibb.co/f4bQ7M1/spaghetti.jpg', description: 'Pâtes spaghetti servies avec une riche sauce à la viande mijotée.', tags: [], allergens: ['Gluten'] },
    { id: 'd18', name: 'Lasagnes à la Bolognaise', category: 'Plat Européen', price: 5500, imageUrl: 'https://i.ibb.co/sKkZ7gK/lasagne.jpg', description: 'Couches de pâtes, sauce bolognaise, béchamel et fromage, gratinées au four.', tags: [], allergens: ['Gluten', 'Lactose'] },
    { id: 'd19', name: 'Steak Frites', category: 'Plat Européen', price: 6500, imageUrl: 'https://i.ibb.co/5vM3h7f/steak-frites.jpg', description: 'Un morceau de boeuf grillé selon votre goût, servi avec des frites croustillantes.', tags: [], allergens: [] },
    { id: 'd20', name: 'Quiche Lorraine', category: 'Plat Européen', price: 3500, imageUrl: 'https://i.ibb.co/7C9R5Sj/quiche.jpg', description: 'Tarte salée à base de pâte brisée, lardons, oeufs et crème fraîche.', tags: [], allergens: ['Gluten', 'Lactose', 'Oeuf'] },
    { id: 'd21', name: 'Boeuf Bourguignon', category: 'Plat Européen', price: 7000, imageUrl: 'https://i.ibb.co/R0gQzC6/bourguignon.jpg', description: 'Ragoût de boeuf mijoté longuement dans du vin rouge avec des légumes.', tags: [], allergens: [] },
    { id: 'd22', name: 'Paella Valenciana', category: 'Plat Européen', price: 8000, imageUrl: 'https://i.ibb.co/YyT4yG9/paella.jpg', description: 'Plat espagnol à base de riz, safran, poulet, lapin et légumes.', tags: [], allergens: ['Crustacés'] },
    { id: 'd23', name: 'Fish and Chips', category: 'Plat Européen', price: 5000, imageUrl: 'https://i.ibb.co/xJzWJ3f/fish-chips.jpg', description: 'Filet de poisson pané et frit, servi avec des frites et une sauce tartare.', tags: [], allergens: ['Gluten', 'Poisson'] },
    { id: 'd24', name: 'Salade César', category: 'Plat Européen', price: 4000, imageUrl: 'https://i.ibb.co/qD4k5W1/salade-cesar.jpg', description: 'Laitue romaine, croûtons, parmesan et poulet grillé, avec une sauce César.', tags: [], allergens: ['Gluten', 'Lactose'] },
    { id: 'd25', name: 'Croque Monsieur', category: 'Plat Européen', price: 3000, imageUrl: 'https://i.ibb.co/L9n7t1c/croque-monsieur.jpg', description: 'Sandwich chaud au jambon et au fromage, gratiné à la béchamel.', tags: [], allergens: ['Gluten', 'Lactose'] },

    // Boissons (7)
    { id: 'd26', name: 'Bissap', category: 'Boisson', price: 500, imageUrl: 'https://i.ibb.co/Z6x53w1/bissap.jpg', description: 'Jus de fleurs d\'hibiscus, rafraîchissant et acidulé.', tags: ['Végétarien'], allergens: [] },
    { id: 'd27', name: 'Jus de Gingembre', category: 'Boisson', price: 500, imageUrl: 'https://i.ibb.co/fHnLd1W/gingembre.jpg', description: 'Jus de gingembre frais, piquant et revigorant.', tags: ['Végétarien', 'Épicé'], allergens: [] },
    { id: 'd28', name: 'Jus de Bouye', category: 'Boisson', price: 700, imageUrl: 'https://i.ibb.co/gV1f3rY/bouye.jpg', description: 'Jus crémeux à base de fruit du baobab (pain de singe).', tags: ['Végétarien'], allergens: ['Lactose'] },
    { id: 'd29', name: 'Coca-Cola', category: 'Boisson', price: 600, imageUrl: 'https://i.ibb.co/Jm2h0Jc/coca.jpg', description: 'Boisson gazeuse rafraîchissante.', tags: [], allergens: [] },
    { id: 'd30', name: 'Fanta', category: 'Boisson', price: 600, imageUrl: 'https://i.ibb.co/qgHqVfQ/fanta.jpg', description: 'Boisson gazeuse à l\'orange.', tags: [], allergens: [] },
    { id: 'd31', name: 'Eau Minérale', category: 'Boisson', price: 500, imageUrl: 'https://i.ibb.co/8YjG02N/eau.jpg', description: 'Bouteille d\'eau minérale de 1,5L.', tags: [], allergens: [] },
    { id: 'd32', name: 'Jus d\'ananas frais', category: 'Boisson', price: 1000, imageUrl: 'https://i.ibb.co/G5f6n8B/ananas.jpg', description: 'Jus d\'ananas pressé minute, sans sucre ajouté.', tags: ['Végétarien'], allergens: [] },
    
    // Desserts (8)
    { id: 'd33', name: 'Thiackry', category: 'Dessert', price: 1500, imageUrl: 'https://i.ibb.co/Y0VvW2g/thiakry.jpg', description: 'Dessert sénégalais à base de semoule de mil et de yaourt sucré.', tags: ['Végétarien'], allergens: ['Lactose', 'Gluten'] },
    { id: 'd34', name: 'Gâteau au chocolat', category: 'Dessert', price: 2000, imageUrl: 'https://i.ibb.co/X3s9x1W/gateau-chocolat.jpg', description: 'Part de gâteau moelleux au chocolat intense.', tags: ['Végétarien'], allergens: ['Gluten', 'Lactose', 'Oeuf'] },
    { id: 'd35', name: 'Crème brûlée', category: 'Dessert', price: 2500, imageUrl: 'https://i.ibb.co/wBFHwH8/creme-brulee.jpg', description: 'Crème riche à la vanille avec une fine couche de caramel croquant.', tags: ['Végétarien'], allergens: ['Lactose', 'Oeuf'] },
    { id: 'd36', name: 'Mousse au chocolat', category: 'Dessert', price: 2000, imageUrl: 'https://i.ibb.co/Vp8r4J6/mousse-chocolat.jpg', description: 'Mousse légère et aérienne au chocolat noir.', tags: ['Végétarien'], allergens: ['Lactose', 'Oeuf'] },
    { id: 'd37', name: 'Tiramisu', category: 'Dessert', price: 3000, imageUrl: 'https://i.ibb.co/hV7d5P9/tiramisu.jpg', description: 'Dessert italien classique au mascarpone, café et biscuits.', tags: ['Végétarien'], allergens: ['Gluten', 'Lactose', 'Oeuf'] },
    { id: 'd38', name: 'Salade de fruits frais', category: 'Dessert', price: 1500, imageUrl: 'https://i.ibb.co/Yc5t9K0/salade-fruits.jpg', description: 'Mélange de fruits de saison, frais et léger.', tags: ['Végétarien'], allergens: [] },
    { id: 'd39', name: 'Beignets Africains (Mikate)', category: 'Dessert', price: 1000, imageUrl: 'https://i.ibb.co/JkdRj1N/beignets.jpg', description: 'Beignets sucrés et moelleux, un délice à tout moment.', tags: ['Végétarien'], allergens: ['Gluten'] },
    { id: 'd40', name: 'Dêguê', category: 'Dessert', price: 1500, imageUrl: 'https://i.ibb.co/Y0VvW2g/thiakry.jpg', description: 'Yaourt crémeux mélangé à des granulés de mil, sucré et savoureux.', tags: ['Végétarien'], allergens: ['Lactose', 'Gluten'] },
];

export const initialBoxes: Box[] = [
    { id: 'b01', name: 'Box Sauce Gombo', price: 2500, description: 'Une sauce gluante et savoureuse, parfaite avec du Tô.' },
    { id: 'b02', name: 'Box Sauce Mafe', price: 3000, description: 'Sauce onctueuse à base de pâte d\'arachide.' },
    { id: 'b03', name: 'Box Sauce Épinards', price: 2500, description: 'Sauce saine et délicieuse aux feuilles d\'épinards.' },
    { id: 'b04', name: 'Box Sauce Graine', price: 3500, description: 'Sauce riche et parfumée à base de noix de palme.' },
];

export const initialOrders: Order[] = [];

export const initialSettings: Settings = {
    paymentMethods: ['Mynita', 'Amanata', 'Alliza', 'Zeyna', 'Espèces'],
    deliveryFees: {
        centreVille: 1000,
        peripherie: 1500,
        nightCentreVille: 1500, // Tarif > 21h
        nightPeripherie: 2000,  // Tarif > 21h
    },
    openingHours: {
        weekdays: '09h à 22h',
        sunday: '12h à 21h',
    },
    deliveryZones: {
        centreVille: ['yantala', 'plateau', 'petit marché', 'grand marché', 'sonuci', 'koira kano', 'kalley', 'gamkalley', 'zarmaganda', 'centre ville', 'ville', 'niamey bas', 'terminus'],
        peripherie: ['aéroport', 'goudel', 'koira teguy', 'saga', 'harobanda', 'talladjé', 'bobiel', 'francophonie', 'niamey 2000'],
    }
};
