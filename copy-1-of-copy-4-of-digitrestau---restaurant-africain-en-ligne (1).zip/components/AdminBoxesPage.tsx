
import React, { useState, useEffect } from 'react';
import PackageIcon from './icons/PackageIcon';
import TrashIcon from './icons/TrashIcon';
import PencilIcon from './icons/PencilIcon';
import PlusIcon from './icons/PlusIcon';
import { Box } from './data';

interface AdminBoxesPageProps {
    boxes: Box[];
    onUpdateBoxes: (boxes: Box[]) => void;
    showNotification: (message: string, type: 'success' | 'error' | 'info') => void;
}

const AdminBoxesPage: React.FC<AdminBoxesPageProps> = ({ boxes, onUpdateBoxes, showNotification }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentBox, setCurrentBox] = useState<Box | null>(null);
    const [boxToDelete, setBoxToDelete] = useState<Box | null>(null);

    const openModal = (box: Box | null = null) => {
        setCurrentBox(box);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setCurrentBox(null);
    };

    const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const boxData = {
            name: formData.get('name') as string,
            price: Number(formData.get('price')),
            description: formData.get('description') as string,
        };

        if (currentBox) {
            const updatedBoxes = boxes.map(b => b.id === currentBox.id ? { ...currentBox, ...boxData } : b);
            onUpdateBoxes(updatedBoxes);
            showNotification(`La box "${boxData.name}" a été mise à jour.`, 'success');
        } else {
            const newBox: Box = { ...boxData, id: `b${Date.now()}` };
            onUpdateBoxes([newBox, ...boxes]);
            showNotification(`La box "${boxData.name}" a été ajoutée.`, 'success');
        }
        closeModal();
    };

    const openDeleteConfirm = (box: Box) => {
        setBoxToDelete(box);
    };

    const closeDeleteConfirm = () => {
        setBoxToDelete(null);
    };

    const handleDelete = () => {
        if (boxToDelete) {
            const updatedBoxes = boxes.filter(b => b.id !== boxToDelete.id);
            onUpdateBoxes(updatedBoxes);
            showNotification(`La box "${boxToDelete.name}" a été supprimée.`, 'success');
            closeDeleteConfirm();
        }
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-serif text-stone-900">Gestion des Boxs</h1>
                <button 
                    onClick={() => openModal()}
                    className="flex items-center space-x-2 bg-amber-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-amber-800 transition duration-300 shadow"
                >
                    <PlusIcon className="w-5 h-5" />
                    <span>Ajouter une Box</span>
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b">
                                <th className="p-4">Nom</th>
                                <th className="p-4">Prix</th>
                                <th className="p-4">Description</th>
                                <th className="p-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {boxes.map(box => (
                                <tr key={box.id} className="border-b hover:bg-stone-50">
                                    <td className="p-4 font-semibold">{box.name}</td>
                                    <td className="p-4">{box.price.toLocaleString('fr-FR')} CFA</td>
                                    <td className="p-4 text-sm text-gray-600 max-w-sm truncate">{box.description}</td>
                                    <td className="p-4">
                                        <div className="flex space-x-2">
                                            <button onClick={() => openModal(box)} className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-5 h-5"/></button>
                                            <button onClick={() => openDeleteConfirm(box)} className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg">
                        <h3 className="text-lg font-bold text-gray-900 mb-4">{currentBox ? 'Modifier la Box' : 'Ajouter une nouvelle Box'}</h3>
                        <form onSubmit={handleFormSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nom de la Box</label>
                                <input type="text" name="name" id="name" defaultValue={currentBox?.name} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                            </div>
                            <div>
                                <label htmlFor="price" className="block text-sm font-medium text-gray-700">Prix (CFA)</label>
                                <input type="number" name="price" id="price" defaultValue={currentBox?.price} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"/>
                            </div>
                            <div>
                                <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                                <textarea name="description" id="description" defaultValue={currentBox?.description} required rows={3} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm"></textarea>
                            </div>
                            <div className="mt-6 flex justify-end space-x-3">
                                <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Annuler</button>
                                <button type="submit" className="px-4 py-2 bg-amber-700 text-white rounded-md hover:bg-amber-800">{currentBox ? 'Sauvegarder' : 'Ajouter'}</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {boxToDelete && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                        <h3 className="text-lg font-bold text-gray-900">Confirmer la Suppression</h3>
                        <p className="mt-2 text-sm text-gray-600">
                           Êtes-vous sûr de vouloir supprimer la box <strong>{boxToDelete.name}</strong> ?
                        </p>
                        <div className="mt-6 flex justify-end space-x-3">
                            <button onClick={closeDeleteConfirm} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Annuler</button>
                            <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Supprimer</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminBoxesPage;
