
import React from 'react';
import StarIcon from './icons/StarIcon';

interface StarRatingProps {
    rating: number;
    interactive?: boolean;
    onRatingChange?: (rating: number) => void;
}

const StarRating: React.FC<StarRatingProps> = ({ rating, interactive = false, onRatingChange }) => {
    return (
        <div className="flex space-x-1">
            {[1, 2, 3, 4, 5].map(star => (
                <button
                    key={star}
                    type="button"
                    disabled={!interactive}
                    onClick={() => interactive && onRatingChange && onRatingChange(star)}
                    className={`${interactive ? 'cursor-pointer' : 'cursor-default'}`}
                >
                    <StarIcon 
                        className={`w-5 h-5 ${
                            star <= rating ? 'text-amber-400' : 'text-stone-300'
                        } ${interactive ? 'hover:text-amber-300' : ''}`}
                    />
                </button>
            ))}
        </div>
    );
};

export default StarRating;
