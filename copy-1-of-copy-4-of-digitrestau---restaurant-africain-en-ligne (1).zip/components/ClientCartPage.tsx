
import React, { useState, useMemo, useEffect } from 'react';
import { CartItem, User, Order, Settings } from './data';
import CartIcon from './icons/CartIcon';
import TrashIcon from './icons/TrashIcon';
import PlusIcon from './icons/PlusIcon';
import MinusIcon from './icons/MinusIcon';
import { Page } from '../App';
import PhoneField from './PhoneField';
import ClockIcon from './icons/ClockIcon';

interface ClientCartPageProps {
  cart: CartItem[];
  updateCartQuantity: (dishId: string, quantity: number) => void;
  clearCart: () => void;
  setPage: (page: Page) => void;
  showNotification: (message: string, type: 'success' | 'error' | 'info') => void;
  addOrder: (newOrder: Omit<Order, 'id' | 'date' | 'status'>) => void;
  currentUser: User | null;
  settings: Settings;
}

const ClientCartPage: React.FC<ClientCartPageProps> = ({ cart, updateCartQuantity, clearCart, setPage, showNotification, addOrder, currentUser, settings }) => {
  const [customerName, setCustomerName] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [isNightRate, setIsNightRate] = useState(false);

  // États pour le Modal de Succès
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [whatsappUrl, setWhatsappUrl] = useState('');

  // Populate form with current user's data
  useEffect(() => {
    if (currentUser) {
        setCustomerName(currentUser.name);
        setCustomerPhone(currentUser.phone);
    }
  }, [currentUser]);

  // Automatic delivery fee calculation (LOGIQUE REVUE)
  useEffect(() => {
    if (deliveryAddress.trim() === '') {
        setDeliveryFee(0);
        return;
    }

    const fees = settings.deliveryFees;
    const zones = settings.deliveryZones;
    
    const now = new Date();
    const currentHour = now.getHours();
    const isAfter21h = currentHour >= 21 || currentHour < 6; // Nuit considérée entre 21h et 6h
    setIsNightRate(isAfter21h);

    // Normalisation de l'adresse pour recherche
    const lowerCaseAddress = deliveryAddress.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    
    const isCentreVille = zones?.centreVille.some(q => lowerCaseAddress.includes(q.toLowerCase()));
    const isPeripherie = zones?.peripherie.some(q => lowerCaseAddress.includes(q.toLowerCase()));

    if (isCentreVille) {
        // Zone Centre Ville
        setDeliveryFee(isAfter21h ? fees.nightCentreVille : fees.centreVille);
    } else if (isPeripherie) {
        // Zone Périphérie
        setDeliveryFee(isAfter21h ? fees.nightPeripherie : fees.peripherie);
    } else {
        // Par défaut si non reconnu : Tarif Périphérie
        setDeliveryFee(isAfter21h ? fees.nightPeripherie : fees.peripherie);
    }

  }, [deliveryAddress, settings]);


  const subTotal = useMemo(() => cart.reduce((total, item) => total + item.price * item.quantity, 0), [cart]);
  const total = subTotal + deliveryFee;

  // Calcul du créneau de livraison (45-60 min)
  const estimatedDeliveryTime = useMemo(() => {
    const formatTime = (date: Date) => date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const now = new Date();
    const arrivalMin = new Date(now.getTime() + 45 * 60000); // 45 minutes
    const arrivalMax = new Date(now.getTime() + 60 * 60000); // 60 minutes
    return `${formatTime(arrivalMin)} - ${formatTime(arrivalMax)}`;
  }, []);

  const isFormValid = customerName.trim() !== '' && deliveryAddress.trim() !== '' && customerPhone.length === 8 && /^\d{8}$/.test(customerPhone) && selectedPaymentMethod !== '';
  
  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
        showNotification("Veuillez vous connecter pour passer une commande.", 'error');
        setPage('compte');
        return;
    }

    if (!isFormValid) {
      showNotification('Veuillez remplir tous les champs correctement.', 'error');
      return;
    }

    // Construct Message
    const itemsSummary = cart.map(item => `- ${item.quantity}x ${item.name} (${(item.price * item.quantity).toLocaleString('fr-FR')} CFA)`).join('\n');
    
    const message = `
*Nouvelle Commande - DigitRestau*

Bonjour, je souhaite passer la commande suivante :

*Client :* ${customerName}
*Téléphone :* ${customerPhone}
*Adresse de livraison :* ${deliveryAddress}
*Moyen de paiement :* ${selectedPaymentMethod}

*Détails de la commande :*
${itemsSummary}

-----------------------------------
*Sous-total :* ${subTotal.toLocaleString('fr-FR')} CFA
*Livraison :* ${deliveryFee.toLocaleString('fr-FR')} CFA ${isNightRate ? '(Tarif Nuit)' : ''}
*TOTAL À PAYER :* *${total.toLocaleString('fr-FR')} CFA*

Merci !
    `;

    const newOrderData = {
        customerName,
        customerId: currentUser.id,
        customerPhone,
        deliveryAddress,
        items: cart.map(({ id, name, quantity, price, specialInstructions }) => ({ id, name, quantity, price, specialInstructions })),
        deliveryFee,
        total,
        paymentMethod: selectedPaymentMethod,
    };

    // 1. Save to DB
    addOrder(newOrderData);

    // 2. Prepare WhatsApp Link
    const url = `https://wa.me/22770032552?text=${encodeURIComponent(message.trim())}`;
    setWhatsappUrl(url);

    // 3. Clear Cart & Show Modal
    clearCart();
    setShowSuccessModal(true);
  };

  const handleCloseModal = () => {
      setShowSuccessModal(false);
      setPage('commande');
  };
  
  return (
    <section id="cart" className="pt-28 pb-10 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <div className="inline-block bg-slate-900/80 p-4 rounded-full mb-4 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                <CartIcon className="w-10 h-10 text-cyan-400" />
            </div>
          <h2 className="text-4xl font-bold font-serif text-white mb-4 neon-text">Votre Panier</h2>
        </div>

        <div className="max-w-4xl mx-auto">
            {cart.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                <div className="lg:col-span-2 bg-slate-900/80 backdrop-blur-md p-6 rounded-xl shadow-xl border border-white/5 space-y-4">
                    <h3 className="text-xl font-bold text-cyan-400 border-b border-white/10 pb-3 mb-3">Articles</h3>
                    {cart.map(item => (
                        <div key={item.id} className="flex items-center space-x-4 border-b border-white/5 pb-4 last:border-0">
                            <img src={item.imageUrl} alt={item.name} className="w-20 h-20 object-cover rounded-lg shadow-md"/>
                            <div className="flex-grow">
                                <p className="font-bold text-slate-200">{item.name}</p>
                                <p className="text-sm text-cyan-500/80">{item.price.toLocaleString('fr-FR')} CFA</p>
                                {item.specialInstructions && <p className="text-xs text-slate-500 italic mt-1">Note: {item.specialInstructions}</p>}
                            </div>
                            <div className="flex items-center space-x-2">
                                <button onClick={() => updateCartQuantity(item.id, item.quantity - 1)} className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition"><MinusIcon className="w-4 h-4"/></button>
                                <span className="font-bold w-6 text-center text-white">{item.quantity}</span>
                                <button onClick={() => updateCartQuantity(item.id, item.quantity + 1)} className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition"><PlusIcon className="w-4 h-4"/></button>
                            </div>
                            <p className="font-bold w-20 text-right text-slate-300">{(item.price * item.quantity).toLocaleString('fr-FR')} CFA</p>
                             <button onClick={() => updateCartQuantity(item.id, 0)} className="p-2 text-slate-500 hover:text-red-500 hover:bg-red-500/10 rounded-full transition"><TrashIcon className="w-5 h-5"/></button>
                        </div>
                    ))}
                     <div className="border-t border-white/10 pt-4 space-y-2 text-right">
                        <div className="flex justify-end space-x-4"><span className="text-slate-400">Sous-total:</span> <span className="font-bold w-32 text-slate-200">{subTotal.toLocaleString('fr-FR')} CFA</span></div>
                        <div className="flex justify-end space-x-4 items-center">
                            <span className="text-slate-400 flex items-center gap-2">
                                {isNightRate && <span className="text-[10px] bg-amber-500/20 text-amber-400 px-1.5 rounded border border-amber-500/50">NUIT</span>}
                                Frais de livraison:
                            </span> 
                            <span className="font-bold w-32 text-slate-200">{deliveryAddress.trim() ? `${deliveryFee.toLocaleString('fr-FR')} CFA` : 'À calculer'}</span>
                        </div>
                        <div className="flex justify-end items-center space-x-4 text-sm py-2">
                            <span className="text-slate-500 flex items-center gap-1.5"><ClockIcon className="w-4 h-4 text-cyan-500" /> Délai estimé (45-60 min):</span> 
                            <span className="font-bold w-32 text-cyan-300">{estimatedDeliveryTime}</span>
                        </div>
                        <div className="flex justify-end space-x-4 text-xl mt-2 pt-2 border-t border-white/5"><span className="font-semibold text-slate-100">Total:</span> <span className="font-bold w-32 text-amber-500 neon-text">{total.toLocaleString('fr-FR')} CFA</span></div>
                    </div>
                </div>

                <div className="lg:col-span-1 bg-slate-900/80 backdrop-blur-md p-6 rounded-xl shadow-xl border border-white/5">
                    <h3 className="text-xl font-bold text-cyan-400 border-b border-white/10 pb-3 mb-4">Informations</h3>
                    <form onSubmit={handleCheckout} className="space-y-4">
                        <div>
                            <label htmlFor="customerName" className="block text-sm font-medium text-slate-400">Nom complet</label>
                            <input type="text" id="customerName" value={customerName} onChange={(e) => setCustomerName(e.target.value)} required className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md text-white shadow-sm focus:ring-cyan-500 focus:border-cyan-500"/>
                        </div>
                        <PhoneField value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} error={phoneError} />
                        <div>
                            <label htmlFor="deliveryAddress" className="block text-sm font-medium text-slate-400">Adresse de livraison</label>
                            <textarea id="deliveryAddress" value={deliveryAddress} onChange={(e) => setDeliveryAddress(e.target.value)} required rows={3} placeholder="Ex: Yantala, Rue 123, Porte 45" className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md text-white shadow-sm focus:ring-cyan-500 focus:border-cyan-500"></textarea>
                            <p className="text-xs text-slate-500 mt-1">Les frais sont calculés selon l'heure (Jour/Nuit) et la zone.</p>
                        </div>
                         <div>
                            <label htmlFor="paymentMethod" className="block text-sm font-medium text-slate-400">Moyen de paiement</label>
                            <select 
                                id="paymentMethod" 
                                value={selectedPaymentMethod} 
                                onChange={(e) => setSelectedPaymentMethod(e.target.value)} 
                                required 
                                className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md text-white shadow-sm focus:ring-cyan-500 focus:border-cyan-500"
                            >
                                <option value="" disabled className="bg-slate-800">Sélectionner une option...</option>
                                {settings.paymentMethods.map(method => (
                                    <option key={method} value={method} className="bg-slate-800">{method}</option>
                                ))}
                            </select>
                        </div>
                        <button 
                            type="submit" 
                            disabled={!isFormValid}
                            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold py-4 px-4 rounded-xl hover:from-cyan-500 hover:to-blue-500 transition duration-300 shadow-lg disabled:bg-slate-700 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed transform hover:-translate-y-1 disabled:transform-none border border-cyan-400/30"
                        >
                            Passer la Commande
                        </button>
                    </form>
                    <div className="mt-4 text-xs text-slate-500 bg-slate-950/50 p-3 rounded-md border border-white/5 space-y-1">
                        <p className="font-semibold text-cyan-500/80 mb-1">Tarifs Livraison (Jour / Nuit)</p>
                        <div className="grid grid-cols-2 gap-2">
                            <div>
                                <span className="block text-slate-400">Centre Ville:</span>
                                <span>{settings.deliveryFees.centreVille} F / <span className="text-amber-500 font-bold">{settings.deliveryFees.nightCentreVille} F</span></span>
                            </div>
                            <div>
                                <span className="block text-slate-400">Périphérie:</span>
                                <span>{settings.deliveryFees.peripherie} F / <span className="text-amber-500 font-bold">{settings.deliveryFees.nightPeripherie} F</span></span>
                            </div>
                        </div>
                        <p className="text-[10px] italic text-slate-600 mt-1">*Tarif nuit appliqué de 21h à 06h.</p>
                    </div>
                </div>
            </div>
            ) : (
                <div className="text-center py-20 bg-slate-900/80 backdrop-blur-md rounded-xl shadow-lg border border-white/5">
                    <h3 className="text-2xl font-serif text-white mb-2">Votre panier est vide</h3>
                    <p className="text-slate-400 mb-8">Parcourez notre menu pour découvrir nos délices !</p>
                    <button onClick={() => setPage('menu')} className="bg-cyan-600 text-white font-bold py-3 px-10 rounded-full hover:bg-cyan-500 transition-all duration-300 ease-in-out shadow-lg transform hover:-translate-y-1">
                        Voir le Menu
                    </button>
                </div>
            )}
        </div>
      </div>

      {/* MODAL SUCCÈS COMMANDE */}
      {showSuccessModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[60] p-4 backdrop-blur-sm">
              <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-8 text-center animate-fade-in-up relative overflow-hidden">
                   <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <div className="w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg shadow-green-500/40">
                          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"></path>
                          </svg>
                      </div>
                   </div>
                  
                  <h3 className="text-2xl font-bold text-slate-900 mb-3 font-serif">Commande<br/>Enregistrée !</h3>
                  <p className="text-slate-500 text-sm mb-8 leading-relaxed">
                      Votre commande a été validée dans l'application.<br/>
                      Veuillez cliquer ci-dessous pour envoyer le récapitulatif au restaurant.
                  </p>
                  
                  <a 
                      href={whatsappUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      onClick={handleCloseModal}
                      className="block w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold py-4 rounded-xl shadow-lg shadow-green-500/30 transition-all transform hover:scale-105 mb-4 flex flex-col items-center justify-center leading-tight"
                  >
                      <span className="text-lg">Envoyer</span>
                      <span className="text-sm opacity-90">sur WhatsApp</span>
                  </a>
                  
                  <button 
                      onClick={handleCloseModal}
                      className="text-slate-400 hover:text-slate-600 text-sm font-medium py-2"
                  >
                      Fermer
                  </button>
              </div>
              <style>{`
                @keyframes fade-in-up {
                    0% { opacity: 0; transform: translateY(20px); }
                    100% { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.4s ease-out forwards;
                }
              `}</style>
          </div>
      )}

    </section>
  );
};

export default ClientCartPage;
