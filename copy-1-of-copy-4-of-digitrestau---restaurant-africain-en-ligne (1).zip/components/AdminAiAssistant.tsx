import React, { useState, useEffect, useRef } from 'react';
import SparklesIcon from './icons/SparklesIcon';
import { Order, Dish } from './data';

interface AdminAiAssistantProps {
    orders: Order[];
    dishes: Dish[];
}

type Message = {
    id: number;
    text: string;
    sender: 'ai' | 'user';
};

const AdminAiAssistant: React.FC<AdminAiAssistantProps> = ({ orders, dishes }) => {
    const [input, setInput] = useState('');
    const [messages, setMessages] = useState<Message[]>([
        { id: 1, text: "Bonjour Manager ! Je suis Jarvis, votre assistant IA. Je peux analyser vos ventes, suggérer des promos ou vérifier vos stocks. Que puis-je faire pour vous ?", sender: 'ai' }
    ]);
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim()) return;

        const userMsg: Message = { id: Date.now(), text: input, sender: 'user' };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);

        // Simulation d'intelligence
        setTimeout(() => {
            let responseText = "Je n'ai pas compris. Essayez 'analyse ventes' ou 'plat populaire'.";
            const lowerInput = userMsg.text.toLowerCase();

            if (lowerInput.includes('vente') || lowerInput.includes('chiffre')) {
                const total = orders.reduce((sum, o) => sum + o.total, 0);
                responseText = `📈 Analyse Financière : Votre chiffre d'affaires total est de ${total.toLocaleString('fr-FR')} CFA sur ${orders.length} commandes. La tendance est positive !`;
            } else if (lowerInput.includes('populaire') || lowerInput.includes('top')) {
                responseText = "🔥 Le plat le plus populaire cette semaine est le 'Thieboudienne Poisson'. Je vous conseille de vérifier vos stocks de poisson pour ce weekend.";
            } else if (lowerInput.includes('promo') || lowerInput.includes('marketing')) {
                responseText = "💡 Idée Marketing : Les commandes baissent légèrement le mardi. Lancez une promo 'Mardi Fou : -15% sur les Boxs' via WhatsApp.";
            } else if (lowerInput.includes('bonjour') || lowerInput.includes('salut')) {
                responseText = "Bonjour ! Prêt à battre des records aujourd'hui ?";
            }

            setMessages(prev => [...prev, { id: Date.now() + 1, text: responseText, sender: 'ai' }]);
            setIsTyping(false);
        }, 1500);
    };

    return (
        <div className="h-[calc(100vh-100px)] flex flex-col">
            <h1 className="text-3xl font-bold font-serif text-white mb-6 flex items-center gap-2 neon-text">
                <SparklesIcon className="w-8 h-8 text-purple-400" /> 
                Jarvis Resto <span className="text-xs font-sans font-normal bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full border border-purple-500/30">BETA</span>
            </h1>

            <div className="flex-1 bg-slate-900 border border-white/10 rounded-xl shadow-2xl overflow-hidden flex flex-col">
                {/* Zone de Chat */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
                    {messages.map(msg => (
                        <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] p-4 rounded-2xl ${
                                msg.sender === 'user' 
                                ? 'bg-cyan-600 text-white rounded-br-none' 
                                : 'bg-slate-800 text-slate-200 border border-white/5 rounded-bl-none'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isTyping && (
                        <div className="flex justify-start">
                            <div className="bg-slate-800 p-4 rounded-2xl rounded-bl-none border border-white/5 flex gap-2">
                                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce"></span>
                                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce delay-100"></span>
                                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce delay-200"></span>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Zone de Saisie */}
                <div className="p-4 bg-slate-950 border-t border-white/10">
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Posez une question à Jarvis..."
                            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all"
                        />
                        <button 
                            onClick={handleSend}
                            className="bg-purple-600 hover:bg-purple-500 text-white p-3 rounded-xl transition-colors shadow-[0_0_15px_rgba(147,51,234,0.3)]"
                        >
                            <SparklesIcon className="w-6 h-6" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminAiAssistant;