
import React, { useState, useEffect } from 'react';
import { Page } from '../App';
import { Dish } from './data';
import { getDishes } from './db';


interface MenuHighlightProps {
  setPage: (page: Page) => void;
}

const MenuItemCard: React.FC<Dish> = ({ imageUrl, name, description }) => (
  <div className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 ease-in-out group transform hover:-translate-y-1">
    <div className="overflow-hidden">
        <img src={imageUrl} alt={name} className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500" />
    </div>
    <div className="p-6">
      <h3 className="text-xl font-bold font-serif text-stone-900 mb-2">{name}</h3>
      <p className="text-stone-600 text-sm">{description}</p>
    </div>
  </div>
);

const MenuHighlight: React.FC<MenuHighlightProps> = ({ setPage }) => {
  const [highlightedDishes, setHighlightedDishes] = useState<Dish[]>([]);

  useEffect(() => {
    const loadDishes = async () => {
        try {
            // On récupère les plats (local ou distant)
            const allDishes = await getDishes();
            const africanDishes = allDishes.filter(d => d.category === 'Plat Africain');
            setHighlightedDishes(africanDishes.slice(0, 4));
        } catch (error) {
            console.error("Failed to load dishes for menu highlight:", error);
        }
    };
    loadDishes();
  }, []);

  return (
    <section id="menu" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold font-serif text-stone-900 mb-4">Nos Spécialités</h2>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto">
            Un aperçu des saveurs qui vous attendent. Chaque plat raconte une histoire.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlightedDishes.map((item) => (
            <MenuItemCard key={item.id} {...item} />
          ))}
        </div>
        <div className="text-center mt-16">
          <button
            onClick={() => setPage('menu')}
            className="bg-amber-700 text-white font-bold py-3 px-8 text-lg rounded-full hover:bg-amber-800 transition-all duration-300 ease-in-out shadow-lg transform hover:-translate-y-1"
          >
            Voir le Menu Complet
          </button>
        </div>
      </div>
    </section>
  );
};

export default MenuHighlight;
