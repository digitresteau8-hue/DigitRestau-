
import React from 'react';
import { Settings } from './data';
import ClockIcon from './icons/ClockIcon';
import CreditCardIcon from './icons/CreditCardIcon';
import DeliveryIcon from './icons/DeliveryIcon';
import MapPinIcon from './icons/MapPinIcon';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    settings: Settings;
}

const InfoSection: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode; }> = ({ icon, title, children }) => (
    <div className="flex items-start space-x-4 p-4 bg-white/5 rounded-lg border border-white/5 hover:border-cyan-500/30 transition-colors">
        <div className="flex-shrink-0 mt-1 text-cyan-400">{icon}</div>
        <div className="flex-1">
            <h4 className="font-bold text-lg text-white mb-2 font-serif">{title}</h4>
            <div className="text-stone-400 text-sm leading-relaxed space-y-1">{children}</div>
        </div>
    </div>
);


const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-[60] p-4 backdrop-blur-md" onClick={onClose}>
            <div className="bg-slate-950 rounded-2xl shadow-2xl w-full max-w-lg border border-cyan-500/20 flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                
                {/* Header */}
                <div className="p-6 border-b border-white/10 flex justify-between items-center bg-slate-900/50 rounded-t-2xl">
                    <div>
                        <h3 className="text-2xl font-bold font-serif text-white neon-text">Infos & Paramètres</h3>
                        <p className="text-xs text-cyan-500 uppercase tracking-widest mt-1">DigitRestau Official</p>
                    </div>
                    <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/5 text-stone-400 hover:bg-red-500/20 hover:text-red-400 transition-all">
                        &times;
                    </button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4 overflow-y-auto custom-scrollbar">
                    
                    <InfoSection icon={<DeliveryIcon className="w-6 h-6" />} title="Frais de Livraison">
                         <div className="grid grid-cols-2 gap-4">
                             <div>
                                 <span className="block font-bold text-white border-b border-white/10 pb-1 mb-1">☀️ Jour (06h - 21h)</span>
                                 <p>Centre-ville : <span className="text-cyan-400 font-bold">{settings.deliveryFees.centreVille} F</span></p>
                                 <p>Périphérie : <span className="text-cyan-400 font-bold">{settings.deliveryFees.peripherie} F</span></p>
                             </div>
                             <div>
                                 <span className="block font-bold text-amber-500 border-b border-amber-500/30 pb-1 mb-1">🌙 Nuit (> 21h)</span>
                                 <p>Centre-ville : <span className="text-amber-400 font-bold">{settings.deliveryFees.nightCentreVille} F</span></p>
                                 <p>Périphérie : <span className="text-amber-400 font-bold">{settings.deliveryFees.nightPeripherie} F</span></p>
                             </div>
                         </div>
                    </InfoSection>

                    <InfoSection icon={<ClockIcon className="w-6 h-6" />} title="Horaires & Délais">
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <p><span className="font-semibold text-white">Lundi - Samedi :</span> {settings.openingHours.weekdays}</p>
                                <p><span className="font-semibold text-white">Dimanche :</span> {settings.openingHours.sunday}</p>
                            </div>
                        </div>
                        <div className="mt-2 pt-2 border-t border-white/10">
                            <p className="flex items-center gap-2">
                                <span className="text-cyan-400 font-bold">⏱️ Temps de livraison moyen :</span> 
                                <span className="text-white">45 mn à 60 mn</span>
                            </p>
                        </div>
                    </InfoSection>
                    
                    <InfoSection icon={<MapPinIcon className="w-6 h-6" />} title="Partenaire de Livraison">
                        <div className="bg-slate-900 p-3 rounded border border-white/5">
                            <p className="font-bold text-lg text-white mb-1">Billo Express</p>
                            <p className="text-xs text-cyan-400 uppercase tracking-wider font-bold mb-2">Rapide - Fiable - Sécurisé</p>
                            <p className="text-stone-400 text-sm">Contact Service Livraison :</p>
                            <a href="tel:+22792080822" className="text-white font-bold hover:text-cyan-400 transition-colors text-lg tracking-wide block mt-1">
                                +227 92 08 08 22
                            </a>
                        </div>
                    </InfoSection>

                    <InfoSection icon={<CreditCardIcon className="w-6 h-6" />} title="Modes de Paiement">
                        <div className="flex flex-wrap gap-2 mt-1">
                            {settings.paymentMethods.map(method => (
                                <span key={method} className="bg-slate-800 text-cyan-200 border border-cyan-500/30 text-xs font-bold px-2.5 py-1 rounded-full shadow-[0_0_10px_rgba(8,145,178,0.2)]">
                                    {method}
                                </span>
                            ))}
                        </div>
                    </InfoSection>

                </div>
                
                {/* Footer */}
                <div className="p-4 border-t border-white/10 bg-slate-900/50 rounded-b-2xl text-center">
                    <p className="text-xs text-stone-600">DigitRestau &copy; 2025 - Tous droits réservés</p>
                </div>
            </div>
            <style>{`
                .custom-scrollbar::-webkit-scrollbar {
                    width: 6px;
                }
                .custom-scrollbar::-webkit-scrollbar-track {
                    background: rgba(255, 255, 255, 0.05);
                }
                .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: rgba(6, 182, 212, 0.3);
                    border-radius: 10px;
                }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                    background: rgba(6, 182, 212, 0.6);
                }
            `}</style>
        </div>
    );
};

export default SettingsModal;
