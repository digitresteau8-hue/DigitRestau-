
import React from 'react';
import DeliveryIcon from './icons/DeliveryIcon';
import CateringIcon from './icons/CateringIcon';
import BoxIcon from './icons/BoxIcon';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => (
  <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 ease-in-out transform hover:-translate-y-2 flex flex-col items-center text-center">
    <div className="bg-orange-100 p-4 rounded-full mb-6">
      {icon}
    </div>
    <h3 className="text-2xl font-bold font-serif text-stone-900 mb-3">{title}</h3>
    <p className="text-stone-600 leading-relaxed">{description}</p>
  </div>
);

const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 bg-stone-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold font-serif text-stone-900 mb-4">Nos Services Exclusifs</h2>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto">
            Plus qu'un restaurant, nous sommes votre partenaire gourmand pour toutes les occasions.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-10">
          <ServiceCard
            icon={<DeliveryIcon className="w-10 h-10 text-orange-600" />}
            title="Livraison Rapide"
            description="Recevez vos plats préférés chauds et savoureux en 45-60 minutes. Un service fiable et sécurisé avec notre partenaire Billo Express."
          />
          <ServiceCard
            icon={<CateringIcon className="w-10 h-10 text-orange-600" />}
            title="Service Traiteur"
            description="Mariages, anniversaires, réunions... Nous sublimons vos événements avec des menus sur-mesure qui raviront vos invités."
          />
          <ServiceCard
            icon={<BoxIcon className="w-10 h-10 text-orange-600" />}
            title="Boxs de Sauces"
            description="Découvrez nos boxs de sauces traditionnelles (Gombo, Mafe, etc.) prêtes à déguster pour accompagner tous vos repas."
          />
        </div>
      </div>
    </section>
  );
};

export default Services;