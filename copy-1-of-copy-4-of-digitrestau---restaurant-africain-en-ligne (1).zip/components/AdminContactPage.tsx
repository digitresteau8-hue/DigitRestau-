
import React from 'react';
import PhoneIcon from './icons/PhoneIcon';

const AdminContactPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold font-serif text-stone-900 mb-6">Messages de Contact</h1>
      <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col items-center text-center">
        <PhoneIcon className="w-16 h-16 text-amber-600 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Boîte de Réception</h2>
        <p className="text-gray-600 max-w-md">
          Ici s'afficheront tous les messages envoyés via le formulaire de contact, permettant à l'administrateur de répondre aux questions des clients.
        </p>
      </div>
    </div>
  );
};

export default AdminContactPage;
