import React, { useState } from 'react';
import MegaphoneIcon from './icons/MegaphoneIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';
import TicketIcon from './icons/TicketIcon';

const AdminMarketingPage: React.FC = () => {
    const [promoMessage, setPromoMessage] = useState("🔥 PROMO FLASH : -20% sur tout le menu aujourd'hui avec le code DIGIT20 ! Commandez vite !");
    
    const handleSendCampaign = () => {
        // Simulation de l'envoi ou ouverture de WhatsApp Web
        const encodedMessage = encodeURIComponent(promoMessage);
        window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
    };

    return (
        <div>
            <h1 className="text-3xl font-bold font-serif text-white mb-6 neon-text">Marketing de Guerre</h1>
            
            <div className="grid lg:grid-cols-2 gap-8">
                
                {/* Section Campagne WhatsApp */}
                <div className="bg-slate-900 border border-white/10 rounded-xl p-8 shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <WhatsAppIcon className="w-32 h-32 text-green-500" />
                    </div>
                    <h2 className="text-xl font-bold text-green-400 mb-4 flex items-center gap-2">
                        <MegaphoneIcon className="w-6 h-6" /> Campagne WhatsApp
                    </h2>
                    <p className="text-slate-400 mb-6">Envoyez des offres exclusives directement sur le téléphone de vos clients.</p>
                    
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-300 mb-2">Message de la campagne</label>
                            <textarea 
                                rows={4}
                                value={promoMessage}
                                onChange={(e) => setPromoMessage(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-4 text-white focus:border-green-500 outline-none"
                            />
                        </div>
                        <button 
                            onClick={handleSendCampaign}
                            className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-3 transition-all transform hover:scale-105 shadow-[0_0_15px_rgba(34,197,94,0.4)]"
                        >
                            <WhatsAppIcon className="w-5 h-5" />
                            Lancer la Diffusion
                        </button>
                        <p className="text-xs text-slate-500 text-center">Redirige vers WhatsApp Web pour sélectionner vos listes de diffusion.</p>
                    </div>
                </div>

                {/* Section Codes Promo */}
                <div className="bg-slate-900 border border-white/10 rounded-xl p-8 shadow-lg relative overflow-hidden">
                     <div className="absolute top-0 right-0 p-4 opacity-10">
                        <TicketIcon className="w-32 h-32 text-amber-500" />
                    </div>
                    <h2 className="text-xl font-bold text-amber-400 mb-4 flex items-center gap-2">
                        <TicketIcon className="w-6 h-6" /> Codes Promo Actifs
                    </h2>
                    
                    <div className="space-y-4">
                        <div className="bg-slate-950 border border-dashed border-slate-700 p-4 rounded-lg flex justify-between items-center">
                            <div>
                                <p className="font-mono font-bold text-white text-lg">BIENVENUE10</p>
                                <p className="text-xs text-slate-400">10% de réduction • Nouveaux clients</p>
                            </div>
                            <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">Actif</span>
                        </div>
                        <div className="bg-slate-950 border border-dashed border-slate-700 p-4 rounded-lg flex justify-between items-center">
                            <div>
                                <p className="font-mono font-bold text-white text-lg">VIP25</p>
                                <p className="text-xs text-slate-400">25% de réduction • Membres Gold</p>
                            </div>
                            <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">Actif</span>
                        </div>
                        
                        <button className="w-full border border-amber-500/50 text-amber-400 font-bold py-3 px-6 rounded-lg hover:bg-amber-500/10 transition-colors">
                            + Créer un nouveau code
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminMarketingPage;