
import React, { useState, useEffect } from 'react';
import { Page } from '../App';
import { User } from './data'; // Import User type
import DashboardIcon from './icons/DashboardIcon';
import DishIcon from './icons/DishIcon';
import CalendarIcon from './icons/CalendarIcon';
import PackageIcon from './icons/PackageIcon';
import ClipboardListIcon from './icons/ClipboardListIcon';
import UserIcon from './icons/UserIcon';
import PhoneIcon from './icons/PhoneIcon';
import SettingsIcon from './icons/SettingsIcon';
import LogoutIcon from './icons/LogoutIcon';
import MegaphoneIcon from './icons/MegaphoneIcon';
import SparklesIcon from './icons/SparklesIcon';
import PencilIcon from './icons/PencilIcon';

interface AdminLayoutProps {
  children: React.ReactNode;
  currentPage: Page;
  setPage: (page: Page) => void;
  onLogout: () => void;
  currentUser: User | null; // Ajout de l'utilisateur actuel
}

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  page: Page;
  currentPage: Page;
  setPage: (page: Page) => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, page, currentPage, setPage }) => {
    const isActive = currentPage === page;
    return (
        <button
            onClick={() => setPage(page)}
            className={`w-full flex items-center space-x-4 px-6 py-4 transition-all duration-200 relative ${
            isActive
                ? 'text-gray-900 font-bold'
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
            }`}
        >
            <div className={`${isActive ? 'text-stone-800' : 'text-gray-400'}`}>
                {icon}
            </div>
            <span className="text-sm">{label}</span>
            {/* Barre jaune active à droite comme sur la maquette */}
            {isActive && (
                <div className="absolute right-0 top-0 bottom-0 w-1.5 bg-amber-400 rounded-l-full"></div>
            )}
        </button>
    );
};


const AdminLayout: React.FC<AdminLayoutProps> = ({ children, currentPage, setPage, onLogout, currentUser }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState('');
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
      const updateDateTime = () => {
          const now = new Date();
          const dateOptions: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short', year: 'numeric' };
          setCurrentDate(now.toLocaleDateString('fr-FR', dateOptions));
          
          const timeOptions: Intl.DateTimeFormatOptions = { hour: '2-digit', minute: '2-digit' };
          setCurrentTime(now.toLocaleTimeString('fr-FR', timeOptions));
      };
      updateDateTime();
      const timer = setInterval(updateDateTime, 60000);
      return () => clearInterval(timer);
  }, []);

  const adminNavLinks = [
    { icon: <DashboardIcon className="w-5 h-5" />, label: 'Tableau de Bord', page: 'admin-dashboard' },
    { icon: <DishIcon className="w-5 h-5" />, label: 'Carte & Plats', page: 'admin-plats' },
    { icon: <ClipboardListIcon className="w-5 h-5" />, label: 'Commandes', page: 'admin-commandes' },
    { icon: <CalendarIcon className="w-5 h-5" />, label: 'Traiteur', page: 'admin-traiteur' },
    { icon: <PackageIcon className="w-5 h-5" />, label: 'Boxs', page: 'admin-boxs' },
    { icon: <MegaphoneIcon className="w-5 h-5" />, label: 'Marketing', page: 'admin-marketing' },
    { icon: <SparklesIcon className="w-5 h-5" />, label: 'Assistant IA', page: 'admin-ai' },
    { icon: <UserIcon className="w-5 h-5" />, label: 'Compte', page: 'admin-compte' },
    { icon: <SettingsIcon className="w-5 h-5" />, label: 'Paramètres', page: 'admin-parametres' },
  ];

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-stone-800">
      
      {/* Overlay sombre quand le menu est ouvert sur mobile */}
      {sidebarOpen && (
          <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)}></div>
      )}

      {/* SIDEBAR (Design Blanc comme maquette) */}
      <aside className={`fixed inset-y-0 left-0 z-50 bg-white w-72 shadow-2xl transition-transform duration-300 ease-in-out transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:relative lg:w-72 flex flex-col`}>
         
         {/* Header Sidebar */}
         <div className="p-6 flex items-center justify-between">
             <h1 className="text-xl font-serif font-bold text-red-900 tracking-wide">DigitRestau</h1>
             <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-gray-400 hover:text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
             </button>
         </div>

         {/* Section Profil Intégré (Cliquable pour modification) */}
         <div 
            className="px-6 pb-8 flex flex-col items-center text-center cursor-pointer group relative z-50"
            onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setPage('admin-compte');
                setSidebarOpen(false); // Fermer le menu sur mobile après clic
            }}
         >
             <div className="w-24 h-24 rounded-full p-1 border-2 border-amber-100 mb-3 relative group-hover:border-amber-300 transition-colors">
                 {/* pointer-events-none est CRUCIAL ici pour que le clic passe au div parent et non à l'image (ce qui ouvre le menu Chrome) */}
                 <img 
                    src={currentUser?.avatarUrl || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"} 
                    alt="Profile" 
                    className="w-full h-full rounded-full object-cover pointer-events-none"
                 />
                 <div className="absolute bottom-0 right-0 bg-white p-1.5 rounded-full shadow-md border border-gray-200 text-amber-600 pointer-events-none">
                    <PencilIcon className="w-3 h-3" />
                 </div>
             </div>
             <h2 className="text-xl font-serif font-bold text-gray-900 group-hover:text-amber-700 transition-colors">{currentUser?.name || 'Lawson Laure'}</h2>
             <p className="text-xs font-bold text-red-600 tracking-widest uppercase mt-1">ADMINISTRATEUR</p>
             <p className="text-[10px] text-gray-400 mt-1">(Touchez pour modifier)</p>
         </div>

        {/* Navigation Links */}
        <nav className="flex-grow overflow-y-auto scrollbar-hide space-y-1">
           {adminNavLinks.map(link => (
                <NavItem 
                    key={link.page}
                    icon={link.icon}
                    label={link.label}
                    page={link.page as Page}
                    currentPage={currentPage}
                    setPage={(p) => { setPage(p); setSidebarOpen(false); }}
                />
           ))}
        </nav>

        {/* Bouton Messages & Déconnexion */}
        <div className="p-6 space-y-4">
            <button 
                onClick={() => setPage('admin-contact')}
                className="w-full flex items-center justify-center space-x-2 bg-[#D32F2F] hover:bg-[#B71C1C] text-white py-3 rounded-xl font-bold shadow-lg transition-transform transform hover:scale-105"
            >
                <PhoneIcon className="w-5 h-5" />
                <span>Messages</span>
            </button>

            <button 
                onClick={onLogout} 
                className="w-full flex items-center space-x-4 px-2 py-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
                <LogoutIcon className="w-5 h-5" />
                <span className="font-medium text-sm">Déconnexion</span>
            </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden bg-white lg:bg-gray-50">
        
        {/* Top Header Mobile (Date & Back) */}
        <header className="bg-white px-4 py-4 flex items-center justify-between shrink-0 z-20 lg:hidden border-b border-gray-100">
            <div className="flex items-center gap-4">
                <button onClick={() => window.history.back()} className="text-gray-800">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                </button>
                <div>
                    <div className="text-lg font-bold text-gray-900 leading-none">{currentDate}</div>
                    <div className="text-xs text-gray-500">{currentTime}</div>
                </div>
            </div>
            
            {/* Menu Burger (Ouvre la sidebar Profil) */}
            <button onClick={() => setSidebarOpen(true)} className="p-2 text-gray-800">
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </header>

        {/* Desktop Header (Simple) */}
        <header className="hidden lg:flex bg-white px-8 py-4 shadow-sm justify-between items-center">
             <div>
                <h2 className="text-2xl font-bold text-gray-800">{currentDate}</h2>
                <p className="text-gray-500 text-sm">Bonne journée, {currentUser?.name || 'Admin'} !</p>
             </div>
             <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600">
                    <SettingsIcon className="w-6 h-6" />
                 </div>
             </div>
        </header>

        <main className="flex-1 overflow-y-auto relative bg-gray-50">
            {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
