

import React, { useState } from 'react';
import { Dish } from './data';
import PlusIcon from './icons/PlusIcon';
import StarRating from './StarRating';
import CheckCircleIcon from './icons/CheckCircleIcon';
import StarIcon from './icons/StarIcon';

interface DishCardProps {
    dish: Dish;
    onAddToCart: (dish: Dish, quantity: number, instructions: string) => void;
    onDishClick: (dish: Dish) => void;
}

const DishCard: React.FC<DishCardProps> = ({ dish, onAddToCart, onDishClick }) => {
    const [added, setAdded] = useState(false);

    const handleAddToCart = (e: React.MouseEvent) => {
        e.stopPropagation(); 
        // Ajout rapide par défaut : 1 unité, pas d'instructions
        onAddToCart(dish, 1, '');
        setAdded(true);
        setTimeout(() => setAdded(false), 2000); 
    };
    
    const averageRating = dish.reviews && dish.reviews.length > 0
        ? dish.reviews.reduce((sum, review) => sum + review.rating, 0) / dish.reviews.length
        : 0;

    return (
        <div 
            className="bg-slate-900 border border-white/5 rounded-2xl overflow-hidden shadow-lg hover:shadow-[0_0_20px_rgba(6,182,212,0.2)] hover:border-cyan-500/30 transition-all duration-500 ease-in-out group transform hover:-translate-y-1 flex flex-col cursor-pointer"
            onClick={() => onDishClick(dish)}
        >
            <div className="overflow-hidden relative h-56">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent opacity-60 z-10"></div>
                <img src={dish.imageUrl} alt={dish.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                
                {/* Badge Catégorie */}
                <div className="absolute top-3 right-3 z-20 bg-black/60 backdrop-blur text-white text-xs px-2 py-1 rounded border border-white/10">
                    {dish.category}
                </div>

                {/* Badges Tags (Épicé, Végé...) */}
                <div className="absolute bottom-3 right-3 z-20 flex flex-col gap-1 items-end">
                    {dish.tags?.includes('Épicé') && (
                        <span className="bg-red-600/80 backdrop-blur text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/50 flex items-center gap-1">
                            🌶️ Épicé
                        </span>
                    )}
                    {dish.tags?.includes('Végétarien') && (
                        <span className="bg-green-600/80 backdrop-blur text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-green-500/50 flex items-center gap-1">
                            🌿 Végé
                        </span>
                    )}
                </div>

                {/* Badge Plat du Jour */}
                {dish.isDailySpecial && (
                    <div className="absolute top-3 left-3 z-20 bg-gradient-to-r from-amber-400 to-yellow-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-[0_0_15px_rgba(245,158,11,0.5)] flex items-center gap-1 animate-pulse">
                        <StarIcon className="w-3 h-3 text-white" />
                        <span className="tracking-wider">PLAT DU JOUR</span>
                    </div>
                )}
            </div>
            <div className="p-6 flex flex-col flex-grow relative z-20 -mt-10">
                <h3 className="text-xl font-bold font-serif text-white mb-2 group-hover:text-cyan-400 transition-colors drop-shadow-md">{dish.name}</h3>
                
                {dish.reviews && dish.reviews.length > 0 && (
                    <div className="flex items-center space-x-2 mb-2">
                        <StarRating rating={averageRating} />
                        <span className="text-xs text-slate-400">({dish.reviews.length})</span>
                    </div>
                )}
                
                <p className="text-slate-400 text-sm flex-grow line-clamp-2 mb-4">{dish.description}</p>
                
                <div className="mt-auto flex justify-between items-center pt-4 border-t border-white/5">
                    <span className="text-xl font-bold text-cyan-400 drop-shadow-[0_0_5px_rgba(34,211,238,0.5)]">{dish.price.toLocaleString('fr-FR')} <span className="text-sm font-normal text-slate-500">CFA</span></span>
                    <button 
                        onClick={handleAddToCart}
                        disabled={added}
                        className={`flex items-center justify-center px-4 h-10 space-x-2 font-bold rounded-lg transition-all duration-300 shadow-lg ${
                            added 
                            ? 'bg-green-500 text-white shadow-[0_0_15px_rgba(34,197,94,0.4)]' 
                            : 'bg-slate-800 text-cyan-400 hover:bg-cyan-600 hover:text-white border border-cyan-500/20 hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                        }`}
                    >
                        {added ? <CheckCircleIcon className="w-5 h-5" /> : <PlusIcon className="w-5 h-5" />}
                        <span>{added ? 'Ajouté' : 'Ajouter'}</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default DishCard;