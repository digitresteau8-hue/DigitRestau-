
import React, { useState } from 'react';
import { Dish, User, Review } from './data';
import MinusIcon from './icons/MinusIcon';
import PlusIcon from './icons/PlusIcon';

interface DishDetailModalProps {
    dish: Dish;
    onClose: () => void;
    onAddToCart: (dish: Dish, quantity: number, instructions: string) => void;
    currentUser: User | null;
    onAddReview: (dishId: string, review: Omit<Review, 'id'>) => void;
    onEditReview: (dishId: string, review: Review) => void;
    onDeleteReview: (dishId: string, reviewId: string) => void;
}

const DishDetailModal: React.FC<DishDetailModalProps> = ({ dish, onClose, onAddToCart }) => {
    const [quantity, setQuantity] = useState(1);
    const [instructions, setInstructions] = useState('');

    const handleAddToCart = () => {
        onAddToCart(dish, quantity, instructions);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/80 flex items-end sm:items-center justify-center z-50 sm:p-4 backdrop-blur-sm" onClick={onClose}>
            <div className="bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                
                {/* Image Héro */}
                <div className="relative h-64 shrink-0">
                    <img src={dish.imageUrl} alt={dish.name} className="w-full h-full object-cover" />
                    <button 
                        onClick={onClose} 
                        className="absolute top-4 right-4 bg-black/50 text-white rounded-full p-2 backdrop-blur hover:bg-black/70 transition"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                {/* Contenu Scrollable */}
                <div className="p-6 overflow-y-auto flex-grow bg-white">
                    <div className="flex justify-between items-start mb-2">
                        <h2 className="text-2xl font-bold font-serif text-gray-900 leading-tight w-3/4">{dish.name}</h2>
                        <div className="text-right">
                             <span className="block text-2xl font-bold text-amber-600">{dish.price.toLocaleString('fr-FR')}</span>
                             <span className="text-sm font-bold text-amber-600">F</span>
                        </div>
                    </div>
                    
                    <p className="text-gray-600 mb-6 leading-relaxed text-sm">{dish.description}</p>
                    
                    {/* Instructions Spéciales */}
                    <div className="mb-6">
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">INSTRUCTIONS SPÉCIALES</label>
                        <textarea
                            value={instructions}
                            onChange={(e) => setInstructions(e.target.value)}
                            placeholder="Sans oignons, sauce à part..."
                            className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl text-gray-800 placeholder-gray-400 focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none resize-none"
                            rows={3}
                        />
                    </div>
                </div>

                {/* Barre du bas fixe */}
                <div className="p-4 bg-white border-t border-gray-100 shrink-0 flex items-center gap-4">
                    {/* Compteur Quantité */}
                    <div className="flex items-center bg-gray-100 rounded-xl px-2 py-2">
                        <button 
                            onClick={() => setQuantity(Math.max(1, quantity - 1))}
                            className="p-2 text-gray-600 hover:text-gray-900 disabled:opacity-50"
                            disabled={quantity <= 1}
                        >
                            <MinusIcon className="w-5 h-5" />
                        </button>
                        <span className="w-8 text-center font-bold text-lg text-gray-900">{quantity}</span>
                        <button 
                            onClick={() => setQuantity(quantity + 1)}
                            className="p-2 text-gray-600 hover:text-gray-900"
                        >
                            <PlusIcon className="w-5 h-5" />
                        </button>
                    </div>

                    {/* Bouton Ajouter */}
                    <button 
                        onClick={handleAddToCart}
                        className="flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-4 px-6 rounded-xl transition-colors shadow-lg shadow-amber-600/30 flex flex-col items-center justify-center leading-none"
                    >
                        <span className="text-lg">Ajouter</span>
                        <span className="text-xs opacity-90 mt-1">{(dish.price * quantity).toLocaleString('fr-FR')} F</span>
                    </button>
                </div>

            </div>
        </div>
    );
};

export default DishDetailModal;
