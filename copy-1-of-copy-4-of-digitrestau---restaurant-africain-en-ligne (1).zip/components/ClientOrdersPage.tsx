
import React from 'react';
import ClipboardListIcon from './icons/ClipboardListIcon';
import { User, Order, OrderStatus, Settings } from './data';
import ClockIcon from './icons/ClockIcon';

// Badge Statut Style "Ticket"
const StatusBadge: React.FC<{ status: OrderStatus }> = ({ status }) => {
  const statusStyles: { [key in OrderStatus]: { bg: string, text: string } } = {
    'Confirmée': { bg: 'bg-purple-100', text: 'text-purple-700' },
    'En préparation': { bg: 'bg-yellow-100', text: 'text-yellow-700' },
    'Prête': { bg: 'bg-cyan-100', text: 'text-cyan-700' },
    'En cours de livraison': { bg: 'bg-blue-100', text: 'text-blue-700' },
    'Livrée': { bg: 'bg-green-100', text: 'text-green-700' },
    'Annulée': { bg: 'bg-red-100', text: 'text-red-700' },
  };

  const style = statusStyles[status];

  return (
    <span className={`px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-md ${style.bg} ${style.text}`}>
      {status}
    </span>
  );
};

interface ClientOrdersPageProps {
    currentUser: User | null;
    orders: Order[];
    settings: Settings;
}

const ClientOrdersPage: React.FC<ClientOrdersPageProps> = ({ currentUser, orders, settings }) => {

  const myOrders = currentUser
    ? orders.filter(order => order.customerId === currentUser.id)
    : [];

  return (
    <section id="orders" className="pt-28 pb-10 min-h-screen bg-gray-50">
      <div className="container mx-auto px-6">
        
        {/* En-tête Section */}
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold font-serif text-gray-900 mb-2">Mes Commandes</h2>
            <p className="text-gray-500 text-sm">Historique et suivi en temps réel</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
            {!currentUser ? (
                <div className="text-center p-8 bg-white rounded-xl shadow-md">
                    <p className="text-gray-500">Connectez-vous pour voir vos commandes.</p>
                </div>
            ) : myOrders.length > 0 ? (
                myOrders.map(order => (
                    <div key={order.id} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
                        
                        {/* Header Carte */}
                        <div className="p-5 pb-0">
                            <div className="flex justify-between items-start mb-1">
                                <p className="text-gray-400 text-xs">
                                    {new Date(order.date).toLocaleDateString('fr-FR')} {new Date(order.date).toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'})}
                                </p>
                                <StatusBadge status={order.status} />
                            </div>
                            <h3 className="text-3xl font-bold text-amber-600 mb-1">{order.total.toLocaleString('fr-FR')} F</h3>
                            <p className="text-xs font-bold text-gray-300 uppercase tracking-widest">WhatsApp Payment</p>
                        </div>

                        <div className="p-5 space-y-4">
                            
                            {/* Carte CLIENT */}
                            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                                <p className="text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">CLIENT</p>
                                <p className="font-bold text-gray-900 text-lg">{order.customerName}</p>
                                <p className="text-gray-600 text-sm">{order.customerPhone}</p>
                                <p className="text-gray-600 text-sm mt-1">{order.deliveryAddress}</p>
                                <p className="text-amber-600 text-xs font-bold mt-1">{order.deliveryFee > 0 ? settings.deliveryZones?.centreVille.some(z => order.deliveryAddress.toLowerCase().includes(z)) ? "Centre Ville" : "Périphérie" : ""}</p>
                            </div>

                            {/* Carte PANIER */}
                            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                                <p className="text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">PANIER</p>
                                <ul className="space-y-2">
                                    {order.items.map(item => (
                                        <li key={item.id} className="flex items-start text-gray-700 text-sm border-b border-gray-100 last:border-0 pb-2 last:pb-0">
                                            <span className="font-bold text-gray-900 mr-2">{item.quantity}x</span>
                                            <div className="flex-grow">
                                                <span>{item.name}</span>
                                                {item.specialInstructions && (
                                                    <p className="text-xs text-gray-400 italic mt-0.5">Note: {item.specialInstructions}</p>
                                                )}
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            </div>

                        </div>

                        {/* Footer Boutons Statuts (Visuel seulement pour le client) */}
                        <div className="px-5 pb-5 pt-0 flex flex-wrap gap-2">
                             {['En Cuisine', 'En Livraison', 'Livré'].map((s) => {
                                 const isActive = order.status === s || (s === 'En Cuisine' && order.status === 'Confirmée') || (s === 'En Cuisine' && order.status === 'En préparation') || (s === 'En Livraison' && order.status === 'En cours de livraison');
                                 const colorClass = s === 'En Cuisine' ? 'bg-blue-100 text-blue-700' : s === 'En Livraison' ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700';
                                 
                                 return isActive ? (
                                     <div key={s} className={`flex-1 py-2 rounded-lg text-center text-xs font-bold ${colorClass}`}>
                                         {s}
                                     </div>
                                 ) : null;
                             })}
                             {order.status === 'Confirmée' && (
                                 <div className="flex-1 py-2 rounded-lg text-center text-xs font-bold bg-red-50 text-red-600 border border-red-100">
                                     Annuler
                                 </div>
                             )}
                        </div>

                    </div>
                ))
            ) : (
                <div className="text-center py-12">
                    <ClipboardListIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Aucune commande pour le moment.</p>
                </div>
            )}
        </div>
      </div>
    </section>
  );
};

export default ClientOrdersPage;
