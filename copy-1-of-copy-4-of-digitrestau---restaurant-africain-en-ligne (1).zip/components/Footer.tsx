
import React from 'react';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-stone-900 text-stone-300">
      <div className="container mx-auto px-6 py-8 flex flex-col sm:flex-row justify-center items-center text-center gap-4">
        <p className="text-sm">&copy; {currentYear} DigitRestau. Tous droits réservés.</p>
        <div className="flex items-center space-x-4">
          <a href="https://www.facebook.com/Allorestau" target="_blank" rel="noopener noreferrer" aria-label="Facebook de DigitRestau" className="hover:text-white transition-colors duration-300">
            <FacebookIcon className="w-5 h-5" />
          </a>
          <a href="https://www.instagram.com/digitrestau" target="_blank" rel="noopener noreferrer" aria-label="Instagram de DigitRestau" className="hover:text-white transition-colors duration-300">
            <InstagramIcon className="w-5 h-5" />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
