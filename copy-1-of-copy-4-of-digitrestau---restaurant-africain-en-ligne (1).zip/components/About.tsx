
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img 
              src="https://picsum.photos/id/1076/600/400" 
              alt="Cuisine Africaine authentique"
              className="rounded-lg shadow-2xl w-full"
            />
          </div>
          <div className="md:w-1/2">
            <h2 className="text-4xl font-bold font-serif text-stone-900 mb-6">Notre Passion, Votre Plaisir</h2>
            <p className="text-lg text-stone-600 mb-4 leading-relaxed">
              Chez DigitRestau, chaque plat est une célébration de la richesse des saveurs africaines et du monde. Nous sélectionnons méticuleusement des ingrédients frais et locaux pour vous offrir une expérience culinaire inoubliable.
            </p>
            <p className="text-lg text-stone-600 leading-relaxed">
              Notre cuisine est un art préparé avec amour et passion. Nous croyons que bien manger est un bonheur, et nous nous engageons à vous livrer ce bonheur directement à votre porte, avec un service rapide, fiable et sécurisé.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;