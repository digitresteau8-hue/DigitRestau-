
import React from 'react';
import CalendarIcon from './icons/CalendarIcon';

const AdminCateringPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold font-serif text-stone-900 mb-6">Gestion des Demandes Traiteur</h1>
      <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col items-center text-center">
        <CalendarIcon className="w-16 h-16 text-amber-600 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Demandes de Service Traiteur</h2>
        <p className="text-gray-600 max-w-md">
          Cette page affichera la liste de toutes les demandes de service traiteur soumises par les clients, avec leurs détails, dates et informations de contact pour un suivi facile.
        </p>
      </div>
    </div>
  );
};

export default AdminCateringPage;
